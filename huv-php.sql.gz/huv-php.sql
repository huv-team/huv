-- Adminer 4.7.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

CREATE DATABASE `huv-php` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `huv-php`;

DROP TABLE IF EXISTS `authors`;
CREATE TABLE `authors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `apellido` varchar(200) DEFAULT NULL,
  `primer_nombre` varchar(200) DEFAULT NULL,
  `segundo_nombre` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `authors` (`id`, `apellido`, `primer_nombre`, `segundo_nombre`) VALUES
(3,	'Bartholomew',	'Mel',	NULL),
(4,	'INTA',	'Instituto Nacional de Tecnología Agropecuaria',	NULL),
(5,	'Parés',	'Gonzalo',	NULL);

DROP TABLE IF EXISTS `authors_sources`;
CREATE TABLE `authors_sources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orden` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `source_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `plantas_autororden_autor_id_b4e676b9_fk_plantas_autor_id` (`author_id`),
  KEY `plantas_autororden_fuente_id_81b5c94f_fk_plantas_fuente_id` (`source_id`),
  CONSTRAINT `authors_sources_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `authors` (`id`),
  CONSTRAINT `authors_sources_ibfk_2` FOREIGN KEY (`source_id`) REFERENCES `sources` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `authors_sources` (`id`, `orden`, `author_id`, `source_id`) VALUES
(18,	1,	3,	9),
(20,	1,	5,	19);

DROP TABLE IF EXISTS `data_sheets`;
CREATE TABLE `data_sheets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `volumen_maceta_ltr` int(11) DEFAULT NULL,
  `profundidad_cm` int(11) DEFAULT NULL,
  `tamano` varchar(200) DEFAULT NULL,
  `horas_sol_min` int(11) DEFAULT NULL,
  `horas_sol_max` int(11) DEFAULT NULL,
  `riego` varchar(200) DEFAULT NULL,
  `tutorado` tinyint(1) NOT NULL,
  `plant_id` int(11) DEFAULT NULL,
  `distancia_max_cm` int(11) DEFAULT NULL,
  `temperatura_max` int(11) DEFAULT NULL,
  `temperatura_min` int(11) DEFAULT NULL,
  `tolera_sombra` tinyint(1) NOT NULL,
  `distancia_min_cm` int(11) DEFAULT NULL,
  `tiempo_cultivo_min_dias` int(11) DEFAULT NULL,
  `tiempo_cultivo_max_dias` int(11) DEFAULT NULL,
  `fecundacion` varchar(20) DEFAULT NULL,
  `aporque` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plantas_ficha_planta_id_77990985_uniq` (`plant_id`),
  CONSTRAINT `data_sheets_ibfk_1` FOREIGN KEY (`plant_id`) REFERENCES `plants` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `data_sheets` (`id`, `volumen_maceta_ltr`, `profundidad_cm`, `tamano`, `horas_sol_min`, `horas_sol_max`, `riego`, `tutorado`, `plant_id`, `distancia_max_cm`, `temperatura_max`, `temperatura_min`, `tolera_sombra`, `distancia_min_cm`, `tiempo_cultivo_min_dias`, `tiempo_cultivo_max_dias`, `fecundacion`, `aporque`) VALUES
(2,	2,	25,	'S',	20,	6,	'1xD',	0,	1,	NULL,	NULL,	NULL,	0,	NULL,	NULL,	NULL,	NULL,	0),
(3,	4,	15,	'M',	20,	4,	'2xD',	0,	2,	20,	NULL,	NULL,	1,	15,	60,	90,	'AU',	0),
(4,	4,	15,	'M',	4,	NULL,	'2xD',	0,	3,	20,	NULL,	NULL,	1,	15,	60,	80,	'CR',	0),
(5,	40,	40,	'L',	25,	5,	'c2D',	0,	37,	NULL,	NULL,	NULL,	0,	NULL,	NULL,	NULL,	NULL,	0),
(6,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	0,	5,	15,	NULL,	NULL,	0,	10,	250,	270,	'CR',	0),
(7,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	0,	4,	25,	NULL,	NULL,	1,	20,	80,	100,	'CR',	0),
(8,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	0,	6,	25,	NULL,	NULL,	1,	20,	120,	150,	'CR',	0),
(9,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	7,	10,	NULL,	NULL,	1,	5,	NULL,	NULL,	'AU',	0),
(10,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	0,	44,	40,	NULL,	NULL,	0,	30,	250,	270,	'CR',	0),
(11,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	8,	50,	NULL,	NULL,	0,	40,	150,	180,	'CR',	0),
(12,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	0,	9,	50,	NULL,	NULL,	0,	40,	250,	270,	'CR',	0),
(13,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	0,	11,	15,	NULL,	NULL,	0,	10,	250,	270,	'CR',	0),
(14,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	36,	150,	NULL,	NULL,	1,	100,	150,	180,	'CR',	0),
(15,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	0,	12,	15,	NULL,	NULL,	1,	10,	250,	270,	'CR',	0),
(16,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	0,	43,	35,	NULL,	NULL,	0,	30,	100,	130,	'CR',	1),
(17,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	0,	10,	50,	NULL,	NULL,	0,	40,	250,	270,	'CR',	1),
(18,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	0,	13,	30,	NULL,	NULL,	0,	20,	90,	120,	'AU',	1),
(19,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	0,	21,	21,	NULL,	NULL,	1,	15,	60,	90,	'AU',	0),
(20,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	0,	15,	30,	NULL,	NULL,	0,	25,	1460,	NULL,	'CR',	1),
(21,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	0,	16,	10,	NULL,	NULL,	1,	5,	80,	90,	'CR',	0),
(22,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	0,	17,	30,	NULL,	NULL,	0,	25,	150,	180,	NULL,	0),
(23,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	0,	18,	30,	NULL,	NULL,	0,	25,	NULL,	NULL,	'AU',	0),
(24,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	0,	19,	50,	NULL,	NULL,	0,	30,	150,	180,	'CR',	1);

DROP TABLE IF EXISTS `data_sheets_seasons`;
CREATE TABLE `data_sheets_seasons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data_sheet_id` int(11) NOT NULL,
  `season_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plantas_ficha_epocas_ficha_id_epoca_id_60e7f44c_uniq` (`data_sheet_id`,`season_id`),
  KEY `plantas_ficha_epocas_epoca_id_3a0d1f1e_fk_plantas_epoca_id` (`season_id`),
  CONSTRAINT `data_sheets_seasons_ibfk_1` FOREIGN KEY (`data_sheet_id`) REFERENCES `data_sheets` (`id`),
  CONSTRAINT `data_sheets_seasons_ibfk_2` FOREIGN KEY (`season_id`) REFERENCES `seasons` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `data_sheets_seasons` (`id`, `data_sheet_id`, `season_id`) VALUES
(70,	3,	20),
(71,	3,	21),
(72,	3,	22),
(66,	3,	69),
(67,	3,	70),
(68,	3,	71),
(69,	3,	72),
(3,	4,	20),
(4,	4,	21),
(17,	4,	22),
(6,	6,	23),
(5,	6,	25),
(7,	7,	26),
(8,	7,	27),
(9,	7,	28),
(10,	8,	29),
(11,	8,	30),
(12,	8,	31),
(13,	9,	32),
(14,	9,	33),
(16,	10,	35),
(20,	10,	44),
(21,	11,	51),
(22,	11,	52),
(23,	12,	25),
(24,	12,	53),
(25,	12,	54),
(26,	13,	54),
(27,	13,	55),
(28,	14,	56),
(29,	14,	57),
(30,	14,	58),
(31,	15,	54),
(32,	15,	55),
(33,	16,	56),
(34,	16,	57),
(35,	16,	59),
(36,	16,	60),
(37,	17,	25),
(38,	17,	53),
(39,	17,	54),
(44,	18,	62),
(45,	18,	63),
(40,	18,	65),
(41,	18,	66),
(42,	18,	67),
(43,	18,	68),
(50,	19,	20),
(51,	19,	21),
(52,	19,	22),
(46,	19,	69),
(47,	19,	70),
(48,	19,	71),
(49,	19,	72),
(53,	20,	73),
(54,	20,	74),
(57,	21,	20),
(55,	21,	72),
(56,	21,	75),
(58,	22,	74),
(59,	22,	76),
(60,	22,	77),
(61,	23,	64),
(62,	23,	78),
(63,	23,	79),
(64,	24,	80),
(65,	24,	81);

DROP TABLE IF EXISTS `data_sheets_sources`;
CREATE TABLE `data_sheets_sources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data_sheet_id` int(11) NOT NULL,
  `source_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plantas_ficha_fuentes_ficha_id_fuente_id_8dd8987e_uniq` (`data_sheet_id`,`source_id`),
  KEY `plantas_ficha_fuentes_fuente_id_23132f93_fk_plantas_fuente_id` (`source_id`),
  CONSTRAINT `data_sheets_sources_ibfk_1` FOREIGN KEY (`data_sheet_id`) REFERENCES `data_sheets` (`id`),
  CONSTRAINT `data_sheets_sources_ibfk_2` FOREIGN KEY (`source_id`) REFERENCES `sources` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `data_sheets_sources` (`id`, `data_sheet_id`, `source_id`) VALUES
(27,	3,	19),
(9,	4,	9),
(8,	4,	19),
(10,	6,	19),
(11,	7,	19),
(12,	8,	19),
(13,	9,	19),
(14,	11,	19),
(15,	12,	19),
(16,	13,	19),
(17,	14,	19),
(18,	15,	19),
(19,	16,	19),
(20,	17,	19),
(21,	18,	19),
(22,	19,	19),
(23,	20,	19),
(24,	22,	19),
(25,	23,	19),
(26,	24,	19);

DROP TABLE IF EXISTS `data_sheets_substrates`;
CREATE TABLE `data_sheets_substrates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data_sheet_id` int(11) NOT NULL,
  `substrate_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plantas_ficha_sustrato_ficha_id_sustrato_id_f2609d69_uniq` (`data_sheet_id`,`substrate_id`),
  KEY `plantas_ficha_sustra_sustrato_id_4aedc587_fk_plantas_s` (`substrate_id`),
  CONSTRAINT `data_sheets_substrates_ibfk_1` FOREIGN KEY (`data_sheet_id`) REFERENCES `data_sheets` (`id`),
  CONSTRAINT `data_sheets_substrates_ibfk_2` FOREIGN KEY (`substrate_id`) REFERENCES `substrates` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `data_sheets_substrates` (`id`, `data_sheet_id`, `substrate_id`) VALUES
(3,	2,	1);

DROP TABLE IF EXISTS `data_sheets_tips`;
CREATE TABLE `data_sheets_tips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data_sheet_id` int(11) NOT NULL,
  `tip_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plantas_ficha_tips_ficha_id_tip_id_2156d431_uniq` (`data_sheet_id`,`tip_id`),
  KEY `plantas_ficha_tips_tip_id_96bbadf3_fk_plantas_tip_id` (`tip_id`),
  CONSTRAINT `data_sheets_tips_ibfk_1` FOREIGN KEY (`data_sheet_id`) REFERENCES `data_sheets` (`id`),
  CONSTRAINT `data_sheets_tips_ibfk_2` FOREIGN KEY (`tip_id`) REFERENCES `tips` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `data_sheets_tips` (`id`, `data_sheet_id`, `tip_id`) VALUES
(2,	2,	2),
(16,	3,	14),
(4,	4,	3),
(5,	7,	4),
(6,	8,	5),
(7,	9,	6),
(8,	15,	7),
(9,	16,	8),
(10,	17,	9),
(11,	18,	10),
(12,	19,	11),
(13,	20,	12),
(14,	21,	13),
(15,	24,	5);

DROP TABLE IF EXISTS `families`;
CREATE TABLE `families` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_popular` varchar(200) DEFAULT NULL,
  `nombre_cientifico` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `families` (`id`, `nombre_popular`, `nombre_cientifico`) VALUES
(1,	'Umbelíferas',	'Apiaceae'),
(2,	'Compuesta',	'Asteraceae'),
(3,	'Crucíferas',	'Brassicaceae'),
(4,	'Solanáceas',	'Solanaceae'),
(5,	'Cucurbitáceas',	'Cucurbitaceae'),
(6,	'Gramíneas',	'Poaceae'),
(7,	'Leguminosas',	'Fabaceae'),
(8,	'Quenopoidáceas',	'Chenopodioideae'),
(9,	'Alliáceas',	'Allioideae'),
(10,	'Labiadas',	'Lamiaceae'),
(11,	'Rosáceas',	'Rosaceae'),
(12,	'tropeoláceas',	'Tropaeolaceae'),
(13,	'Convolvuláceas',	'Convolvulaceae');

DROP TABLE IF EXISTS `interactions`;
CREATE TABLE `interactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `interactions` (`id`, `description`, `type`) VALUES
(1,	NULL,	'B'),
(6,	NULL,	'B'),
(7,	'',	'B'),
(8,	'',	'B'),
(9,	'',	'B'),
(11,	'',	'B'),
(12,	'',	'B'),
(13,	'',	'B'),
(14,	'',	'B'),
(15,	'',	'B'),
(16,	'',	'B'),
(17,	'',	'B'),
(18,	'',	'B'),
(19,	'',	'B'),
(20,	'',	'B'),
(21,	'',	'B'),
(22,	'',	'B'),
(23,	'',	'B'),
(24,	'',	'B'),
(25,	'',	'B'),
(26,	'',	'B'),
(27,	'',	'B'),
(28,	'',	'B'),
(29,	'',	'B'),
(30,	'',	'B'),
(31,	'',	'B'),
(32,	'',	'B'),
(33,	'',	'B');

DROP TABLE IF EXISTS `interactions_plants`;
CREATE TABLE `interactions_plants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `interaction_id` int(11) NOT NULL,
  `plant_id` int(11) NOT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `plantas_interaccion_actor_interaccion_id_planta_id_5c65194c_uniq` (`interaction_id`,`plant_id`),
  KEY `plantas_interaccion__planta_id_31a3b788_fk_plantas_p` (`plant_id`),
  CONSTRAINT `interactions_plants_ibfk_1` FOREIGN KEY (`interaction_id`) REFERENCES `interactions` (`id`),
  CONSTRAINT `interactions_plants_ibfk_2` FOREIGN KEY (`plant_id`) REFERENCES `plants` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `interactions_plants` (`id`, `interaction_id`, `plant_id`, `type`) VALUES
(2,	7,	5,	'actor'),
(3,	8,	39,	'actor'),
(4,	9,	40,	'actor'),
(6,	11,	17,	'actor'),
(7,	12,	42,	'actor'),
(8,	13,	34,	'actor'),
(9,	14,	1,	'actor'),
(10,	15,	2,	'actor'),
(11,	15,	21,	'actor'),
(12,	15,	14,	'actor'),
(13,	16,	2,	'actor'),
(14,	16,	3,	'actor'),
(15,	16,	21,	'actor'),
(16,	17,	1,	'actor'),
(17,	17,	2,	'actor'),
(18,	17,	34,	'actor'),
(19,	17,	29,	'actor'),
(20,	18,	32,	'actor'),
(21,	18,	1,	'actor'),
(22,	18,	5,	'actor'),
(23,	19,	43,	'actor'),
(24,	20,	2,	'actor'),
(25,	20,	46,	'actor'),
(26,	21,	40,	'actor'),
(27,	21,	45,	'actor'),
(28,	21,	31,	'actor'),
(29,	22,	32,	'actor'),
(30,	22,	1,	'actor'),
(31,	22,	2,	'actor'),
(32,	22,	31,	'actor'),
(33,	23,	40,	'actor'),
(34,	23,	14,	'actor'),
(35,	24,	32,	'actor'),
(36,	24,	1,	'actor'),
(37,	24,	2,	'actor'),
(38,	24,	31,	'actor'),
(39,	25,	50,	'actor'),
(40,	25,	51,	'actor'),
(41,	25,	44,	'actor'),
(42,	26,	40,	'actor'),
(43,	26,	45,	'actor'),
(44,	26,	31,	'actor'),
(45,	27,	8,	'actor'),
(46,	27,	27,	'actor'),
(47,	27,	14,	'actor'),
(48,	28,	3,	'actor'),
(49,	29,	2,	'actor'),
(50,	29,	3,	'actor'),
(51,	30,	32,	'actor'),
(52,	30,	9,	'actor'),
(53,	30,	10,	'actor'),
(54,	30,	31,	'actor'),
(55,	31,	2,	'actor'),
(56,	31,	29,	'actor'),
(57,	32,	2,	'actor'),
(58,	32,	3,	'actor'),
(59,	33,	3,	'actor');

DROP TABLE IF EXISTS `phinxlog`;
CREATE TABLE `phinxlog` (
  `version` bigint(20) NOT NULL,
  `migration_name` varchar(100) DEFAULT NULL,
  `start_time` timestamp NULL DEFAULT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `breakpoint` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `phinxlog` (`version`, `migration_name`, `start_time`, `end_time`, `breakpoint`) VALUES
(20210424203439,	'CreateUsers',	'2021-04-24 20:51:38',	'2021-04-24 20:51:39',	0);

DROP TABLE IF EXISTS `plants`;
CREATE TABLE `plants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_popular` varchar(200) NOT NULL,
  `nombre_cientifico` varchar(200) DEFAULT NULL,
  `family_id` int(11) DEFAULT NULL,
  `variedad` varchar(200) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `plantas_planta_tipo_id_b6de5d3c_fk_plantas_tipo_id` (`type_id`),
  KEY `plantas_planta_familia_id_77279843_fk_plantas_familia_id` (`family_id`),
  CONSTRAINT `plants_ibfk_1` FOREIGN KEY (`family_id`) REFERENCES `families` (`id`),
  CONSTRAINT `plants_ibfk_2` FOREIGN KEY (`type_id`) REFERENCES `types` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plants` (`id`, `nombre_popular`, `nombre_cientifico`, `family_id`, `variedad`, `type_id`) VALUES
(1,	'Zanahoria',	'Daucus carota',	1,	NULL,	4),
(2,	'Lechuga',	'Lactuca',	2,	NULL,	3),
(3,	'Acelga',	'Beta vulgaris',	8,	NULL,	3),
(4,	'Albahaca',	'Ocimum basilicum',	10,	NULL,	2),
(5,	'Ajo',	'Allium sativun',	9,	NULL,	4),
(6,	'Apio',	'Apium graveolens',	1,	NULL,	2),
(7,	'Arveja',	'Pisum sativum',	7,	NULL,	1),
(8,	'Berenjena',	NULL,	4,	NULL,	1),
(9,	'Brócoli',	NULL,	3,	NULL,	2),
(10,	'Coliflor',	NULL,	3,	NULL,	2),
(11,	'Cebolla',	NULL,	9,	NULL,	4),
(12,	'Cebolla de verdeo',	NULL,	9,	NULL,	3),
(13,	'Chaucha',	NULL,	7,	'Enana',	1),
(14,	'Maíz',	NULL,	6,	NULL,	1),
(15,	'Espárrago',	NULL,	9,	NULL,	4),
(16,	'Espinaca',	NULL,	8,	NULL,	3),
(17,	'Frutilla',	'Fragaria',	11,	NULL,	1),
(18,	'Haba',	NULL,	7,	NULL,	1),
(19,	'Hinojo',	NULL,	1,	NULL,	2),
(21,	'Escarola',	NULL,	2,	NULL,	3),
(22,	'Melón',	NULL,	5,	NULL,	1),
(23,	'Sandía',	NULL,	5,	NULL,	1),
(24,	'Papa',	NULL,	4,	NULL,	4),
(25,	'Pepino',	NULL,	5,	NULL,	1),
(26,	'Perejil',	NULL,	1,	NULL,	2),
(27,	'Pimiento',	NULL,	4,	NULL,	1),
(28,	'Puerro',	NULL,	9,	NULL,	2),
(29,	'Rabanito',	NULL,	3,	NULL,	4),
(30,	'Radicheta',	NULL,	2,	NULL,	3),
(31,	'Remolacha',	NULL,	8,	NULL,	4),
(32,	'Repollo',	NULL,	3,	NULL,	2),
(33,	'Rúcula',	NULL,	3,	NULL,	3),
(34,	'Tomate',	NULL,	4,	NULL,	1),
(35,	'Zapallo',	NULL,	5,	NULL,	1),
(36,	'Cayote',	NULL,	5,	NULL,	1),
(37,	'Zapallito',	NULL,	5,	NULL,	1),
(38,	'Zuccini',	NULL,	5,	NULL,	1),
(39,	'Caléndula',	NULL,	2,	NULL,	2),
(40,	'Taco de Reina',	NULL,	11,	NULL,	2),
(41,	'Morrón',	NULL,	4,	NULL,	1),
(42,	'Manzanila',	NULL,	NULL,	NULL,	2),
(43,	'Choclo',	NULL,	6,	NULL,	1),
(44,	'Batata',	NULL,	13,	NULL,	4),
(45,	'Ajenjo',	NULL,	NULL,	NULL,	3),
(46,	'Copete',	NULL,	NULL,	NULL,	2),
(50,	'Maní',	NULL,	NULL,	NULL,	1),
(51,	'Poroto',	NULL,	NULL,	NULL,	1),
(52,	'kljlkjasd',	'askdlñ',	1,	'lsdk',	1),
(53,	'Ramirola',	'Ramirus Ambrientus',	1,	NULL,	4),
(54,	'Ramirola',	'Ramirus Ambrientus',	1,	NULL,	4);

DROP TABLE IF EXISTS `rotations`;
CREATE TABLE `rotations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `anterior_id` int(11) DEFAULT NULL,
  `posterior_id` int(11) DEFAULT NULL,
  `actual_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `plantas_rotaciones_anterior_id_f8637944_fk_plantas_familia_id` (`anterior_id`),
  KEY `plantas_rotaciones_posterior_id_93dca290_fk_plantas_familia_id` (`posterior_id`),
  KEY `plantas_rotaciones_actual_id_d25be4a3_fk_plantas_familia_id` (`actual_id`),
  CONSTRAINT `plantas_rotaciones_actual_id_d25be4a3_fk_plantas_familia_id` FOREIGN KEY (`actual_id`) REFERENCES `families` (`id`),
  CONSTRAINT `plantas_rotaciones_anterior_id_f8637944_fk_plantas_familia_id` FOREIGN KEY (`anterior_id`) REFERENCES `families` (`id`),
  CONSTRAINT `plantas_rotaciones_posterior_id_93dca290_fk_plantas_familia_id` FOREIGN KEY (`posterior_id`) REFERENCES `families` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `rotations` (`id`, `anterior_id`, `posterior_id`, `actual_id`) VALUES
(3,	5,	3,	2),
(4,	3,	4,	1),
(5,	2,	1,	3),
(6,	1,	6,	4),
(7,	4,	7,	6),
(8,	6,	8,	7),
(9,	7,	9,	8),
(10,	8,	5,	9);

DROP TABLE IF EXISTS `seasons`;
CREATE TABLE `seasons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(20) NOT NULL,
  `desde_mes` varchar(20) NOT NULL,
  `hasta_mes` varchar(20) NOT NULL,
  `desde_dia` int(11) NOT NULL,
  `hasta_dia` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique days and months` (`tipo`,`desde_dia`,`desde_mes`,`hasta_dia`,`hasta_mes`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `seasons` (`id`, `tipo`, `desde_mes`, `hasta_mes`, `desde_dia`, `hasta_dia`) VALUES
(18,	'AL',	'1',	'12',	0,	0),
(51,	'AL',	'7',	'10',	0,	0),
(44,	'AL',	'7',	'8',	0,	0),
(26,	'AL',	'8',	'1',	0,	0),
(56,	'AL',	'8',	'8',	0,	0),
(22,	'CO',	'1',	'12',	0,	0),
(60,	'CO',	'1',	'4',	0,	0),
(58,	'CO',	'1',	'5',	0,	0),
(74,	'CO',	'10',	'12',	0,	0),
(25,	'CO',	'11',	'1',	0,	0),
(24,	'CO',	'11',	'12',	0,	0),
(28,	'CO',	'11',	'4',	0,	0),
(63,	'CO',	'12',	'2',	0,	0),
(30,	'CO',	'12',	'4',	0,	0),
(52,	'CO',	'2',	'5',	0,	0),
(35,	'CO',	'4',	'5',	0,	0),
(62,	'CO',	'6',	'8',	0,	0),
(81,	'CO',	'7',	'10',	0,	0),
(33,	'CO',	'7',	'11',	0,	0),
(75,	'CO',	'8',	'10',	0,	0),
(31,	'CO',	'8',	'9',	0,	0),
(79,	'CO',	'9',	'12',	0,	0),
(55,	'CO',	'11',	'1',	2,	1),
(19,	'SI',	'1',	'12',	0,	0),
(80,	'SI',	'1',	'4',	0,	0),
(54,	'SI',	'2',	'4',	0,	0),
(20,	'SI',	'2',	'6',	0,	0),
(61,	'SI',	'3',	'12',	0,	0),
(23,	'SI',	'3',	'5',	0,	0),
(64,	'SI',	'3',	'6',	0,	0),
(32,	'SI',	'3',	'8',	0,	0),
(66,	'SI',	'3',	'6',	0,	21),
(76,	'SI',	'4',	'5',	0,	0),
(69,	'SI',	'7',	'8',	0,	0),
(21,	'SI',	'8',	'12',	0,	0),
(73,	'SI',	'8',	'9',	0,	0),
(57,	'SI',	'9',	'1',	0,	0),
(53,	'SI',	'9',	'10',	0,	0),
(27,	'SI',	'9',	'11',	0,	0),
(29,	'SI',	'9',	'3',	0,	0),
(65,	'SI',	'9',	'12',	21,	21),
(72,	'TR',	'2',	'6',	0,	0),
(78,	'TR',	'3',	'6',	0,	0),
(67,	'TR',	'3',	'6',	0,	21),
(77,	'TR',	'4',	'5',	0,	0),
(70,	'TR',	'7',	'8',	0,	0),
(71,	'TR',	'8',	'12',	0,	0),
(59,	'TR',	'9',	'1',	0,	0),
(68,	'TR',	'9',	'12',	21,	21);

DROP TABLE IF EXISTS `sources`;
CREATE TABLE `sources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `otros` longtext,
  `url` varchar(200) DEFAULT NULL,
  `titulo` longtext,
  `acceso` date DEFAULT NULL,
  `anio` longtext,
  `nombre_revista` longtext,
  `capitulo` longtext,
  `contenido` longtext,
  `edicion` int(11) DEFAULT NULL,
  `editorial` longtext,
  `nombre_pag` longtext,
  `numero` int(11) DEFAULT NULL,
  `pag_fin` int(11) DEFAULT NULL,
  `pag_inicio` int(11) DEFAULT NULL,
  `red_social` varchar(10) DEFAULT NULL,
  `tipo` varchar(20) DEFAULT NULL,
  `tipo_cont` longtext,
  `usuario` longtext,
  `volumen` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `sources` (`id`, `otros`, `url`, `titulo`, `acceso`, `anio`, `nombre_revista`, `capitulo`, `contenido`, `edicion`, `editorial`, `nombre_pag`, `numero`, `pag_fin`, `pag_inicio`, `red_social`, `tipo`, `tipo_cont`, `usuario`, `volumen`) VALUES
(9,	'',	NULL,	'All new square foot gardening : more projects, new solutions, grow vegetables anywhere',	NULL,	'2018',	'',	'',	'',	3,	'Cool Springs Press',	'',	NULL,	NULL,	NULL,	NULL,	'LI',	'',	'',	NULL),
(19,	'',	'http://prohuerta.inta.gob.ar/wp-content/uploads/2020/03/Planificador-PH-imprimir-2020-baja.pdf',	'Planificador de Siembra Prohuerta',	'2021-01-11',	'',	NULL,	NULL,	NULL,	NULL,	'',	'ProHuerta | Programa del Ministerio de Desarrollo Social de la Nación e INTA',	NULL,	NULL,	NULL,	NULL,	'PW',	NULL,	NULL,	NULL);

DROP TABLE IF EXISTS `substrates`;
CREATE TABLE `substrates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tierra` varchar(200) DEFAULT NULL,
  `potasio` tinyint(1) NOT NULL,
  `nitrogeno` tinyint(1) NOT NULL,
  `fosforo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `substrates` (`id`, `tierra`, `potasio`, `nitrogeno`, `fosforo`) VALUES
(1,	'Suelto',	0,	0,	0);

DROP TABLE IF EXISTS `tips`;
CREATE TABLE `tips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contenido` longtext,
  `source_id` int(11) DEFAULT NULL,
  `titulo` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `plantas_tip_fuente_id_6c2d03a8_fk_plantas_fuente_id` (`source_id`),
  CONSTRAINT `tips_ibfk_1` FOREIGN KEY (`source_id`) REFERENCES `sources` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `tips` (`id`, `contenido`, `source_id`, `titulo`) VALUES
(2,	'Cuando asome de la tierra',	19,	'Cosecha raíces'),
(3,	'Corte de tallos florales que se van secando',	19,	'Cosecha semilla acelga'),
(4,	'Junto varas florales antes de que se abran',	19,	'cosecha albahaca'),
(5,	'Dejo ir en vicio, corto cabezuelas (amarillento/amarronadas) antes de que pierdan semillas',	19,	'Cosecha semillas zanahoria'),
(6,	'Arranco plantas enteras con vainas pardo amarillentas',	19,	'Cosecha semillas arveja'),
(7,	'Corto cabezas florales cuando comienzan a abrirse los primeros capullos',	19,	'Cosecha semillas cebolla'),
(8,	'Dejar secar choclos en plantas. Descarto las semillas de la punta y base.',	19,	'Cosecha choclo'),
(9,	'Arranco plantas enteras amarillas',	19,	'Cosecha semilla brócoli'),
(10,	'Frutos amarillos o secos antes que abran',	19,	'Cosecha chaucha'),
(11,	'Corto planta entera cuando abren los panes',	19,	'Cosecha semilla escarola'),
(12,	'Corto tallos tiernos',	19,	'Cosecha esparrago'),
(13,	'Planta entera amarillenta',	19,	'Cosecha semilla espinaca'),
(14,	'Planta entera antes de la floración',	19,	'cosecha lechuga');

DROP TABLE IF EXISTS `types`;
CREATE TABLE `types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `types` (`id`, `nombre`) VALUES
(1,	'FR'),
(2,	'FL'),
(3,	'HO'),
(4,	'RA');

-- 2021-05-29 19:50:49
