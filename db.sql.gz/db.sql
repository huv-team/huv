-- Adminer 4.7.7 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

USE `huvdev`;

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `auth_group`;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `auth_group_permissions`;
CREATE TABLE `auth_group_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `auth_permission`;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1,	'Can add log entry',	1,	'add_logentry'),
(2,	'Can change log entry',	1,	'change_logentry'),
(3,	'Can delete log entry',	1,	'delete_logentry'),
(4,	'Can view log entry',	1,	'view_logentry'),
(5,	'Can add permission',	2,	'add_permission'),
(6,	'Can change permission',	2,	'change_permission'),
(7,	'Can delete permission',	2,	'delete_permission'),
(8,	'Can view permission',	2,	'view_permission'),
(9,	'Can add group',	3,	'add_group'),
(10,	'Can change group',	3,	'change_group'),
(11,	'Can delete group',	3,	'delete_group'),
(12,	'Can view group',	3,	'view_group'),
(13,	'Can add user',	4,	'add_user'),
(14,	'Can change user',	4,	'change_user'),
(15,	'Can delete user',	4,	'delete_user'),
(16,	'Can view user',	4,	'view_user'),
(17,	'Can add content type',	5,	'add_contenttype'),
(18,	'Can change content type',	5,	'change_contenttype'),
(19,	'Can delete content type',	5,	'delete_contenttype'),
(20,	'Can view content type',	5,	'view_contenttype'),
(21,	'Can add session',	6,	'add_session'),
(22,	'Can change session',	6,	'change_session'),
(23,	'Can delete session',	6,	'delete_session'),
(24,	'Can view session',	6,	'view_session'),
(25,	'Can add familia',	7,	'add_familia'),
(26,	'Can change familia',	7,	'change_familia'),
(27,	'Can delete familia',	7,	'delete_familia'),
(28,	'Can view familia',	7,	'view_familia'),
(29,	'Can add planta',	8,	'add_planta'),
(30,	'Can change planta',	8,	'change_planta'),
(31,	'Can delete planta',	8,	'delete_planta'),
(32,	'Can view planta',	8,	'view_planta'),
(33,	'Can add epoca',	9,	'add_epoca'),
(34,	'Can change epoca',	9,	'change_epoca'),
(35,	'Can delete epoca',	9,	'delete_epoca'),
(36,	'Can view epoca',	9,	'view_epoca'),
(37,	'Can add fuente',	10,	'add_fuente'),
(38,	'Can change fuente',	10,	'change_fuente'),
(39,	'Can delete fuente',	10,	'delete_fuente'),
(40,	'Can view fuente',	10,	'view_fuente'),
(41,	'Can add sustrato',	11,	'add_sustrato'),
(42,	'Can change sustrato',	11,	'change_sustrato'),
(43,	'Can delete sustrato',	11,	'delete_sustrato'),
(44,	'Can view sustrato',	11,	'view_sustrato'),
(45,	'Can add tipo',	12,	'add_tipo'),
(46,	'Can change tipo',	12,	'change_tipo'),
(47,	'Can delete tipo',	12,	'delete_tipo'),
(48,	'Can view tipo',	12,	'view_tipo'),
(49,	'Can add tip',	13,	'add_tip'),
(50,	'Can change tip',	13,	'change_tip'),
(51,	'Can delete tip',	13,	'delete_tip'),
(52,	'Can view tip',	13,	'view_tip'),
(53,	'Can add rotaciones',	14,	'add_rotaciones'),
(54,	'Can change rotaciones',	14,	'change_rotaciones'),
(55,	'Can delete rotaciones',	14,	'delete_rotaciones'),
(56,	'Can view rotaciones',	14,	'view_rotaciones'),
(57,	'Can add interacciones',	15,	'add_interacciones'),
(58,	'Can change interacciones',	15,	'change_interacciones'),
(59,	'Can delete interacciones',	15,	'delete_interacciones'),
(60,	'Can view interacciones',	15,	'view_interacciones'),
(61,	'Can add ficha',	16,	'add_ficha'),
(62,	'Can change ficha',	16,	'change_ficha'),
(63,	'Can delete ficha',	16,	'delete_ficha'),
(64,	'Can view ficha',	16,	'view_ficha'),
(65,	'Can add autor',	17,	'add_autor'),
(66,	'Can change autor',	17,	'change_autor'),
(67,	'Can delete autor',	17,	'delete_autor'),
(68,	'Can view autor',	17,	'view_autor'),
(69,	'Can add autor order',	18,	'add_autororder'),
(70,	'Can change autor order',	18,	'change_autororder'),
(71,	'Can delete autor order',	18,	'delete_autororder'),
(72,	'Can view autor order',	18,	'view_autororder'),
(73,	'Can add interaccion',	15,	'add_interaccion'),
(74,	'Can change interaccion',	15,	'change_interaccion'),
(75,	'Can delete interaccion',	15,	'delete_interaccion'),
(76,	'Can view interaccion',	15,	'view_interaccion'),
(77,	'Can add rotacion',	14,	'add_rotacion'),
(78,	'Can change rotacion',	14,	'change_rotacion'),
(79,	'Can delete rotacion',	14,	'delete_rotacion'),
(80,	'Can view rotacion',	14,	'view_rotacion'),
(81,	'Can add autor orden',	19,	'add_autororden'),
(82,	'Can change autor orden',	19,	'change_autororden'),
(83,	'Can delete autor orden',	19,	'delete_autororden'),
(84,	'Can view autor orden',	19,	'view_autororden');

DROP TABLE IF EXISTS `auth_user`;
CREATE TABLE `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
(1,	'pbkdf2_sha256$150000$SPOkMJuJ3gwU$oxdhtYHxGiqQwdWnOaJNsiw8HefAOMCtpkHY0YAmtDo=',	'2021-01-10 05:20:25.501797',	1,	'rama',	'',	'',	'ramirohgatti@gmail.com',	1,	1,	'2020-12-06 22:17:15.042058');

DROP TABLE IF EXISTS `auth_user_groups`;
CREATE TABLE `auth_user_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `auth_user_user_permissions`;
CREATE TABLE `auth_user_user_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `django_admin_log`;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES
(1,	'2020-12-07 03:00:18.670095',	'1',	'Umbelíferas',	1,	'[{\"added\": {}}]',	7,	1),
(2,	'2020-12-07 03:13:20.936046',	'1',	'Zanahoria',	1,	'[{\"added\": {}}]',	8,	1),
(3,	'2020-12-07 03:36:43.986843',	'1',	'Epoca object (1)',	1,	'[{\"added\": {}}]',	9,	1),
(4,	'2020-12-07 03:42:23.361209',	'1',	'Epoca object (1)',	2,	'[]',	9,	1),
(5,	'2020-12-07 03:42:38.502428',	'2',	'Epoca object (2)',	1,	'[{\"added\": {}}]',	9,	1),
(6,	'2020-12-07 03:42:53.432504',	'3',	'Epoca object (3)',	1,	'[{\"added\": {}}]',	9,	1),
(7,	'2020-12-07 03:43:09.089548',	'4',	'Epoca object (4)',	1,	'[{\"added\": {}}]',	9,	1),
(8,	'2020-12-07 03:43:54.527263',	'1',	'Sustrato object (1)',	1,	'[{\"added\": {}}]',	11,	1),
(9,	'2020-12-07 03:44:27.119869',	'1',	'Fuente object (1)',	1,	'[{\"added\": {}}]',	10,	1),
(10,	'2020-12-07 03:44:33.703781',	'1',	'Tip object (1)',	1,	'[{\"added\": {}}]',	13,	1),
(11,	'2020-12-07 03:45:33.553197',	'2',	'Fuente object (2)',	1,	'[{\"added\": {}}]',	10,	1),
(12,	'2020-12-07 03:45:47.462513',	'1',	'Ficha object (1)',	1,	'[{\"added\": {}}]',	16,	1),
(13,	'2020-12-07 03:57:31.202435',	'1',	'Epoca object (1)',	3,	'',	9,	1),
(14,	'2020-12-07 03:58:08.354466',	'1',	'Ficha object (1)',	2,	'[{\"changed\": {\"fields\": [\"epoca_semillero\"]}}]',	16,	1),
(15,	'2020-12-07 04:00:28.833170',	'1',	'Ficha object (1)',	2,	'[]',	16,	1),
(16,	'2020-12-07 04:00:58.533234',	'1',	'Ficha object (1)',	2,	'[]',	16,	1),
(17,	'2020-12-07 04:18:26.047656',	'3',	'Cuidar la tierra',	1,	'[{\"added\": {}}]',	10,	1),
(18,	'2020-12-07 04:20:54.398837',	'1',	'Tip object (1)',	3,	'',	13,	1),
(19,	'2020-12-07 04:21:45.680076',	'1',	'Zanahoria',	3,	'',	16,	1),
(20,	'2020-12-07 04:25:52.609568',	'5',	'Nunca',	1,	'[{\"added\": {}}]',	9,	1),
(21,	'2020-12-07 04:27:08.628322',	'6',	'Anual',	1,	'[{\"added\": {}}]',	9,	1),
(22,	'2020-12-07 04:32:32.279778',	'2',	'Tip object (2)',	1,	'[{\"added\": {}}]',	13,	1),
(23,	'2020-12-07 04:33:19.469455',	'2',	'Suelto',	1,	'[{\"added\": {}}]',	11,	1),
(24,	'2020-12-07 04:33:28.004051',	'2',	'Zanahoria',	1,	'[{\"added\": {}}]',	16,	1),
(25,	'2020-12-07 04:33:41.425035',	'4',	'None',	3,	'',	9,	1),
(26,	'2020-12-07 04:33:41.530827',	'3',	'None',	3,	'',	9,	1),
(27,	'2020-12-07 04:33:41.614368',	'2',	'None',	3,	'',	9,	1),
(28,	'2020-12-07 04:34:06.146993',	'2',	'None',	3,	'',	10,	1),
(29,	'2020-12-07 04:34:06.357017',	'1',	'None',	3,	'',	10,	1),
(30,	'2020-12-07 04:36:21.619314',	'4',	'Mel Bartholomew',	1,	'[{\"added\": {}}]',	10,	1),
(31,	'2020-12-07 04:37:21.656916',	'2',	'Suelto',	3,	'',	11,	1),
(32,	'2020-12-07 04:37:34.933023',	'1',	'Tipo object (1)',	1,	'[{\"added\": {}}]',	12,	1),
(33,	'2020-12-07 04:38:15.054835',	'2',	'FL',	1,	'[{\"added\": {}}]',	12,	1),
(34,	'2020-12-07 04:38:24.101302',	'3',	'HO',	1,	'[{\"added\": {}}]',	12,	1),
(35,	'2020-12-07 04:38:32.374214',	'4',	'RA',	1,	'[{\"added\": {}}]',	12,	1),
(36,	'2020-12-07 04:45:06.834792',	'2',	'Cosecha',	2,	'[{\"changed\": {\"fields\": [\"descripcion\", \"contenido\", \"fuente\"]}}]',	13,	1),
(37,	'2020-12-07 04:47:26.337649',	'1',	'Interacciones object (1)',	1,	'[{\"added\": {}}]',	15,	1),
(38,	'2020-12-07 04:57:50.917773',	'2',	'Compuesta',	1,	'[{\"added\": {}}]',	7,	1),
(39,	'2020-12-07 04:57:54.924246',	'2',	'Lechuga',	1,	'[{\"added\": {}}]',	8,	1),
(40,	'2020-12-07 05:21:17.350105',	'1',	'Zanahoria',	2,	'[]',	15,	1),
(41,	'2020-12-07 05:31:57.161138',	'1',	'Zanahoria',	2,	'[]',	15,	1),
(42,	'2020-12-07 05:33:39.811555',	'1',	'Rotaciones object (1)',	1,	'[{\"added\": {}}]',	14,	1),
(43,	'2020-12-07 05:37:45.764292',	'3',	'Crucíferas',	1,	'[{\"added\": {}}]',	7,	1),
(44,	'2020-12-07 05:39:27.381672',	'1',	'None',	3,	'',	14,	1),
(45,	'2020-12-07 05:39:36.862305',	'3',	'None',	1,	'[{\"added\": {}}]',	14,	1),
(46,	'2020-12-07 05:44:37.953711',	'4',	'Solanáceas',	1,	'[{\"added\": {}}]',	7,	1),
(47,	'2020-12-07 05:44:46.408106',	'4',	'Umbelíferas',	1,	'[{\"added\": {}}]',	14,	1),
(48,	'2020-12-07 05:48:56.432941',	'5',	'Cucurbitáceas',	1,	'[{\"added\": {}}]',	7,	1),
(49,	'2020-12-07 05:49:03.170488',	'5',	'Compuesta',	1,	'[{\"added\": {}}]',	14,	1),
(50,	'2020-12-07 05:49:38.329268',	'3',	'Compuesta',	2,	'[{\"changed\": {\"fields\": [\"anterior\"]}}]',	14,	1),
(51,	'2020-12-07 05:49:55.440923',	'5',	'Crucíferas',	2,	'[{\"changed\": {\"fields\": [\"anterior\", \"actual\", \"posterior\"]}}]',	14,	1),
(52,	'2020-12-07 05:51:20.962194',	'6',	'Gramíneas',	1,	'[{\"added\": {}}]',	7,	1),
(53,	'2020-12-07 05:51:34.014964',	'6',	'Solanáceas',	1,	'[{\"added\": {}}]',	14,	1),
(54,	'2020-12-07 05:52:39.216548',	'7',	'Leguminosas',	1,	'[{\"added\": {}}]',	7,	1),
(55,	'2020-12-07 05:52:44.219094',	'7',	'Gramíneas',	1,	'[{\"added\": {}}]',	14,	1),
(56,	'2020-12-07 05:53:40.827819',	'8',	'Quenopoidáceas',	1,	'[{\"added\": {}}]',	7,	1),
(57,	'2020-12-07 05:53:47.745901',	'8',	'Leguminosas',	1,	'[{\"added\": {}}]',	14,	1),
(58,	'2020-12-07 05:54:54.718913',	'9',	'Alliáceas',	1,	'[{\"added\": {}}]',	7,	1),
(59,	'2020-12-07 05:55:56.264350',	'9',	'Quenopoidáceas',	1,	'[{\"added\": {}}]',	14,	1),
(60,	'2020-12-07 05:56:22.759937',	'10',	'Alliáceas',	1,	'[{\"added\": {}}]',	14,	1),
(61,	'2020-12-08 03:40:01.337019',	'3',	'Acelga',	1,	'[{\"added\": {}}]',	8,	1),
(62,	'2020-12-08 03:46:14.775105',	'10',	'Labiadas',	1,	'[{\"added\": {}}]',	7,	1),
(63,	'2020-12-08 03:46:27.437526',	'4',	'Albahaca',	1,	'[{\"added\": {}}]',	8,	1),
(64,	'2020-12-08 03:49:01.457329',	'5',	'Ajo',	1,	'[{\"added\": {}}]',	8,	1),
(65,	'2020-12-08 03:52:08.928783',	'6',	'Apio',	1,	'[{\"added\": {}}]',	8,	1),
(66,	'2020-12-08 03:54:30.574319',	'7',	'Arveja',	1,	'[{\"added\": {}}]',	8,	1),
(67,	'2020-12-08 03:56:17.676505',	'8',	'Berenjena',	1,	'[{\"added\": {}}]',	8,	1),
(68,	'2020-12-08 03:56:53.318275',	'9',	'Brócoli',	1,	'[{\"added\": {}}]',	8,	1),
(69,	'2020-12-08 03:57:20.590674',	'10',	'Coliflor',	1,	'[{\"added\": {}}]',	8,	1),
(70,	'2020-12-08 03:57:53.820555',	'11',	'Cebolla',	1,	'[{\"added\": {}}]',	8,	1),
(71,	'2020-12-08 03:58:18.658735',	'12',	'Cebolla de verdeo',	1,	'[{\"added\": {}}]',	8,	1),
(72,	'2020-12-08 03:58:50.028075',	'13',	'Chaucha',	1,	'[{\"added\": {}}]',	8,	1),
(73,	'2020-12-08 03:59:23.487047',	'14',	'Choclo',	1,	'[{\"added\": {}}]',	8,	1),
(74,	'2020-12-08 04:00:05.948193',	'15',	'Espárrago',	1,	'[{\"added\": {}}]',	8,	1),
(75,	'2020-12-08 04:00:19.875699',	'16',	'Espinaca',	1,	'[{\"added\": {}}]',	8,	1),
(76,	'2020-12-08 04:02:57.840988',	'11',	'Rosáceas',	1,	'[{\"added\": {}}]',	7,	1),
(77,	'2020-12-08 04:03:04.241761',	'17',	'Frutilla',	1,	'[{\"added\": {}}]',	8,	1),
(78,	'2020-12-08 04:03:17.216109',	'18',	'Haba',	1,	'[{\"added\": {}}]',	8,	1),
(79,	'2020-12-08 04:04:11.407078',	'19',	'Hinojo',	1,	'[{\"added\": {}}]',	8,	1),
(80,	'2020-12-08 04:04:25.079739',	'20',	'Lechuga',	1,	'[{\"added\": {}}]',	8,	1),
(81,	'2020-12-08 04:04:45.928698',	'21',	'Escarola',	1,	'[{\"added\": {}}]',	8,	1),
(82,	'2020-12-08 04:05:03.541353',	'22',	'Melón',	1,	'[{\"added\": {}}]',	8,	1),
(83,	'2020-12-08 04:05:41.559544',	'23',	'Sandía',	1,	'[{\"added\": {}}]',	8,	1),
(84,	'2020-12-08 04:05:59.492247',	'24',	'Papa',	1,	'[{\"added\": {}}]',	8,	1),
(85,	'2020-12-08 04:06:16.706803',	'25',	'Pepino',	1,	'[{\"added\": {}}]',	8,	1),
(86,	'2020-12-08 04:07:20.835582',	'26',	'Perejil',	1,	'[{\"added\": {}}]',	8,	1),
(87,	'2020-12-08 04:07:43.338246',	'27',	'Pimiento',	1,	'[{\"added\": {}}]',	8,	1),
(88,	'2020-12-08 04:08:14.476249',	'28',	'Puerro',	1,	'[{\"added\": {}}]',	8,	1),
(89,	'2020-12-08 04:08:57.993011',	'29',	'Rabanito',	1,	'[{\"added\": {}}]',	8,	1),
(90,	'2020-12-08 04:09:12.855456',	'30',	'Radicheta',	1,	'[{\"added\": {}}]',	8,	1),
(91,	'2020-12-08 04:09:36.062017',	'31',	'Remolacha',	1,	'[{\"added\": {}}]',	8,	1),
(92,	'2020-12-08 04:09:55.493199',	'32',	'Repollo',	1,	'[{\"added\": {}}]',	8,	1),
(93,	'2020-12-08 04:10:04.978199',	'33',	'Rúcula',	1,	'[{\"added\": {}}]',	8,	1),
(94,	'2020-12-08 04:10:20.360793',	'34',	'Tomate',	1,	'[{\"added\": {}}]',	8,	1),
(95,	'2020-12-08 04:11:28.393192',	'20',	'Lechuga',	3,	'',	8,	1),
(96,	'2020-12-08 04:12:20.152181',	'35',	'Zapallo',	1,	'[{\"added\": {}}]',	8,	1),
(97,	'2020-12-08 04:12:44.028160',	'36',	'Cayote',	1,	'[{\"added\": {}}]',	8,	1),
(98,	'2020-12-08 04:13:22.937686',	'37',	'Zapallito',	1,	'[{\"added\": {}}]',	8,	1),
(99,	'2020-12-08 04:13:48.745125',	'38',	'Zuccini',	1,	'[{\"added\": {}}]',	8,	1),
(100,	'2020-12-08 04:18:41.434054',	'5',	'INTA',	1,	'[{\"added\": {}}]',	10,	1),
(101,	'2020-12-08 04:20:42.011640',	'3',	'Cosecha semilla',	1,	'[{\"added\": {}}]',	13,	1),
(102,	'2020-12-08 04:23:10.639364',	'3',	'Cosecha semilla acelga',	2,	'[{\"changed\": {\"fields\": [\"descripcion\"]}}]',	13,	1),
(103,	'2020-12-08 04:23:36.426168',	'2',	'Cosecha raíces',	2,	'[{\"changed\": {\"fields\": [\"descripcion\"]}}]',	13,	1),
(104,	'2020-12-08 04:23:44.189217',	'2',	'Cosecha raíces',	2,	'[]',	13,	1),
(105,	'2020-12-08 04:34:53.533966',	'6',	'SI de ENE a DIC',	2,	'[{\"changed\": {\"fields\": [\"desde\", \"hasta\"]}}]',	9,	1),
(106,	'2020-12-08 04:35:02.138908',	'5',	'SE de ENE a DIC',	2,	'[{\"changed\": {\"fields\": [\"desde\", \"hasta\"]}}]',	9,	1),
(107,	'2020-12-08 04:37:58.381989',	'5',	'SE de ENE a ENE',	2,	'[{\"changed\": {\"fields\": [\"hasta\"]}}]',	9,	1),
(108,	'2020-12-08 04:39:18.184647',	'2',	'Zanahoria',	2,	'[{\"changed\": {\"fields\": [\"epoca_trasplante\", \"sustrato\", \"fuentes\"]}}]',	16,	1),
(109,	'2020-12-09 03:17:32.165017',	'3',	'Lechuga',	1,	'[{\"added\": {}}]',	16,	1),
(110,	'2020-12-09 03:17:40.394682',	'3',	'Lechuga',	2,	'[]',	16,	1),
(111,	'2020-12-09 03:27:13.385177',	'4',	'Acelga',	1,	'[{\"added\": {}}]',	16,	1),
(112,	'2020-12-09 03:27:24.805248',	'3',	'Lechuga',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	16,	1),
(113,	'2020-12-09 03:27:31.813110',	'2',	'Zanahoria',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	16,	1),
(114,	'2020-12-09 03:33:56.380740',	'39',	'Caléndula',	1,	'[{\"added\": {}}]',	8,	1),
(115,	'2020-12-09 03:34:05.581928',	'5',	'Acelga',	1,	'[{\"added\": {}}]',	15,	1),
(116,	'2020-12-09 03:34:53.637447',	'38',	'Zuccini',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(117,	'2020-12-09 03:34:57.887893',	'38',	'Zuccini',	2,	'[]',	8,	1),
(118,	'2020-12-09 03:35:05.204224',	'37',	'Zapallito',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(119,	'2020-12-09 03:35:18.766578',	'35',	'Zapallo',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(120,	'2020-12-09 03:35:24.816656',	'34',	'Tomate',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(121,	'2020-12-09 03:35:30.898426',	'33',	'Rúcula',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(122,	'2020-12-09 03:35:41.099085',	'32',	'Repollo',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(123,	'2020-12-09 03:35:49.831036',	'31',	'Remolacha',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(124,	'2020-12-09 03:35:55.667862',	'30',	'Radicheta',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(125,	'2020-12-09 03:36:07.810310',	'29',	'Rabanito',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(126,	'2020-12-09 03:36:21.958269',	'28',	'Puerro',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(127,	'2020-12-09 03:36:28.841172',	'27',	'Pimiento',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(128,	'2020-12-09 03:36:40.926347',	'26',	'Perejil',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(129,	'2020-12-09 03:36:46.708033',	'25',	'Pepino',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(130,	'2020-12-09 03:36:53.194042',	'24',	'Papa',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(131,	'2020-12-09 03:37:01.778471',	'23',	'Sandía',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(132,	'2020-12-09 03:37:09.374400',	'22',	'Melón',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(133,	'2020-12-09 03:37:19.405100',	'21',	'Escarola',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(134,	'2020-12-09 03:37:28.866936',	'19',	'Hinojo',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(135,	'2020-12-09 03:37:37.884176',	'18',	'Haba',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(136,	'2020-12-09 03:37:46.385864',	'17',	'Frutilla',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(137,	'2020-12-09 03:37:54.780014',	'16',	'Espinaca',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(138,	'2020-12-09 03:38:07.178711',	'15',	'Espárrago',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(139,	'2020-12-09 03:38:15.288704',	'14',	'Choclo',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(140,	'2020-12-09 03:38:22.500253',	'13',	'Chaucha',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(141,	'2020-12-09 03:38:37.889185',	'12',	'Cebolla de verdeo',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(142,	'2020-12-09 03:38:45.961224',	'11',	'Cebolla',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(143,	'2020-12-09 03:38:58.312098',	'10',	'Coliflor',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(144,	'2020-12-09 03:39:06.019275',	'9',	'Brócoli',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(145,	'2020-12-09 03:39:15.039720',	'8',	'Berenjena',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(146,	'2020-12-27 03:37:09.712569',	'11',	'Rosáceas',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\"]}}]',	7,	1),
(147,	'2020-12-27 03:37:16.526417',	'11',	'Rosáceas',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\"]}}]',	7,	1),
(148,	'2020-12-27 03:39:41.775774',	'39',	'Caléndula',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\"]}}]',	8,	1),
(149,	'2020-12-27 03:39:51.768307',	'38',	'Zuccini',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(150,	'2020-12-27 03:39:56.571105',	'39',	'Caléndula',	2,	'[{\"changed\": {\"fields\": [\"variedad\"]}}]',	8,	1),
(151,	'2020-12-27 03:46:59.515759',	'36',	'Cayote',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\", \"tipo\"]}}]',	8,	1),
(152,	'2020-12-27 15:31:31.205750',	'37',	'Zapallito',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(153,	'2020-12-27 15:31:46.977042',	'37',	'Zapallito',	2,	'[]',	8,	1),
(154,	'2020-12-27 15:43:27.194239',	'5',	'Zapallito',	1,	'[{\"added\": {}}]',	16,	1),
(155,	'2020-12-27 15:45:08.757516',	'2',	'Zanahoria',	2,	'[{\"changed\": {\"fields\": [\"fuentes\"]}}]',	16,	1),
(156,	'2020-12-27 15:45:24.391639',	'3',	'Lechuga',	2,	'[]',	16,	1),
(157,	'2020-12-27 16:03:57.273042',	'4',	'Acelga',	2,	'[{\"changed\": {\"fields\": [\"epoca_semillero\", \"epoca_siembra\", \"epoca_trasplante\", \"epoca_cosecha\", \"sustrato\"]}}]',	16,	1),
(158,	'2020-12-27 16:05:11.015409',	'3',	'Lechuga',	2,	'[{\"changed\": {\"fields\": [\"volumen_maceta_ltr\", \"epoca_semillero\", \"epoca_siembra\", \"epoca_trasplante\", \"epoca_cosecha\", \"sustrato\", \"tips\"]}}]',	16,	1),
(159,	'2020-12-27 17:37:42.314568',	'2',	'Cosecha raíces',	2,	'[]',	13,	1),
(160,	'2020-12-27 17:37:59.104433',	'3',	'Cosecha semilla acelga',	2,	'[]',	13,	1),
(161,	'2020-12-27 17:38:21.222711',	'3',	'Cosecha semilla acelga',	2,	'[]',	13,	1),
(162,	'2020-12-27 17:42:58.988330',	'5',	'Acelga',	2,	'[{\"changed\": {\"fields\": [\"benefica\"]}}]',	15,	1),
(163,	'2020-12-27 17:45:28.803614',	'1',	'Zanahoria',	2,	'[{\"changed\": {\"fields\": [\"benefica\", \"perjudicial\"]}}]',	15,	1),
(164,	'2020-12-28 21:05:42.597909',	'35',	'Zapallo',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(165,	'2020-12-28 21:05:43.093913',	'34',	'Tomate',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(166,	'2020-12-28 21:05:43.281965',	'33',	'Rúcula',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(167,	'2020-12-28 21:05:43.472135',	'32',	'Repollo',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(168,	'2020-12-28 21:05:43.763909',	'31',	'Remolacha',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(169,	'2020-12-28 21:05:43.962014',	'30',	'Radicheta',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(170,	'2020-12-28 21:05:44.162797',	'29',	'Rabanito',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(171,	'2020-12-28 21:05:44.352214',	'28',	'Puerro',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(172,	'2020-12-28 21:05:44.534527',	'27',	'Pimiento',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(173,	'2020-12-28 21:05:44.734607',	'26',	'Perejil',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(174,	'2020-12-28 21:05:44.945790',	'25',	'Pepino',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(175,	'2020-12-28 21:05:45.101887',	'24',	'Papa',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(176,	'2020-12-28 21:05:45.269325',	'23',	'Sandía',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(177,	'2020-12-28 21:05:45.403044',	'22',	'Melón',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(178,	'2020-12-28 21:05:45.537593',	'21',	'Escarola',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(179,	'2020-12-28 21:05:45.723797',	'19',	'Hinojo',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(180,	'2020-12-28 21:05:45.923503',	'18',	'Haba',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(181,	'2020-12-28 21:05:46.123724',	'17',	'Frutilla',	2,	'[{\"changed\": {\"fields\": [\"variedad\"]}}]',	8,	1),
(182,	'2020-12-28 21:05:46.418487',	'16',	'Espinaca',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(183,	'2020-12-28 21:05:46.619271',	'15',	'Espárrago',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(184,	'2020-12-28 21:05:46.987361',	'14',	'Choclo',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(185,	'2020-12-28 21:05:47.276370',	'13',	'Chaucha',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(186,	'2020-12-28 21:05:47.477327',	'12',	'Cebolla de verdeo',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(187,	'2020-12-28 21:05:47.700350',	'11',	'Cebolla',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(188,	'2020-12-28 21:05:47.846671',	'10',	'Coliflor',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(189,	'2020-12-28 21:05:48.046569',	'9',	'Brócoli',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(190,	'2020-12-28 21:05:48.249163',	'8',	'Berenjena',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"variedad\"]}}]',	8,	1),
(191,	'2020-12-28 21:05:48.424706',	'7',	'Arveja',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(192,	'2020-12-28 21:05:48.635973',	'6',	'Apio',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(193,	'2020-12-28 21:05:48.835736',	'5',	'Ajo',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(194,	'2020-12-28 21:05:49.046948',	'4',	'Albahaca',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(195,	'2020-12-28 21:05:49.258496',	'3',	'Acelga',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(196,	'2020-12-28 21:05:49.454509',	'2',	'Lechuga',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(197,	'2020-12-28 21:05:49.621834',	'1',	'Zanahoria',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	8,	1),
(198,	'2020-12-28 21:16:05.059792',	'3',	'Beta vulgaris',	2,	'[{\"changed\": {\"fields\": [\"nombre_popular\"]}}]',	8,	1),
(199,	'2020-12-28 21:17:14.124003',	'3',	'Acelga',	2,	'[{\"changed\": {\"fields\": [\"nombre_popular\"]}}]',	8,	1),
(200,	'2020-12-28 21:46:56.678678',	'3',	'Beta vulgaris',	2,	'[{\"changed\": {\"fields\": [\"nombre_popular\"]}}]',	8,	1),
(201,	'2020-12-28 21:49:01.909939',	'3',	'Acelga',	2,	'[{\"changed\": {\"fields\": [\"nombre_popular\"]}}]',	8,	1),
(202,	'2020-12-28 21:49:36.664939',	'7',	'Arveja',	2,	'[{\"changed\": {\"fields\": [\"variedad\"]}}]',	8,	1),
(203,	'2020-12-28 21:49:36.832475',	'1',	'Zanahoria',	2,	'[{\"changed\": {\"fields\": [\"variedad\"]}}]',	8,	1),
(204,	'2020-12-28 22:47:25.423728',	'6',	'Zapallito',	1,	'[{\"added\": {}}]',	15,	1),
(205,	'2020-12-28 22:48:54.158885',	'40',	'Taco de Reina',	1,	'[{\"added\": {}}]',	8,	1),
(206,	'2020-12-28 22:49:02.319178',	'6',	'Zapallito',	2,	'[{\"changed\": {\"fields\": [\"benefica\"]}}]',	15,	1),
(207,	'2020-12-28 22:51:31.134819',	'6',	'Zapallito',	2,	'[]',	15,	1),
(208,	'2020-12-28 22:57:31.782945',	'41',	'Morrón',	1,	'[{\"added\": {}}]',	8,	1),
(209,	'2020-12-28 22:57:38.514798',	'6',	'Zapallito',	2,	'[{\"changed\": {\"fields\": [\"benefica\"]}}]',	15,	1),
(210,	'2020-12-29 02:11:38.066895',	'14',	'Maiz',	2,	'[{\"changed\": {\"fields\": [\"nombre_popular\"]}}]',	8,	1),
(211,	'2020-12-29 02:12:11.590861',	'14',	'Maíz',	2,	'[{\"changed\": {\"fields\": [\"nombre_popular\"]}}]',	8,	1),
(212,	'2020-12-29 04:55:53.666667',	'1',	'Autor object (1)',	1,	'[{\"added\": {}}]',	17,	1),
(213,	'2020-12-29 04:56:14.513534',	'5',	'None',	3,	'',	10,	1),
(214,	'2020-12-29 05:41:01.491300',	'2',	'Mel Bartholomew',	1,	'[{\"added\": {}}]',	17,	1),
(215,	'2020-12-29 06:14:20.545816',	'3',	'INTA',	2,	'[{\"changed\": {\"fields\": [\"autores\"]}}]',	10,	1),
(216,	'2020-12-29 06:14:29.897002',	'3',	'INTA',	2,	'[{\"changed\": {\"fields\": [\"autores\"]}}]',	10,	1),
(217,	'2020-12-29 06:14:39.943999',	'4',	'INTA',	2,	'[{\"changed\": {\"fields\": [\"autores\"]}}]',	10,	1),
(218,	'2020-12-29 06:15:47.429948',	'3',	'Mel Bartholomew',	2,	'[{\"changed\": {\"fields\": [\"autores\"]}}]',	10,	1),
(219,	'2020-12-29 07:28:20.221934',	'4',	'Fuente object (4)',	3,	'',	10,	1),
(220,	'2020-12-29 07:28:20.354160',	'3',	'Fuente object (3)',	3,	'',	10,	1),
(221,	'2020-12-29 07:48:33.666193',	'6',	'INTA',	1,	'[{\"added\": {}}]',	10,	1),
(222,	'2020-12-29 07:48:42.345674',	'6',	'INTA',	2,	'[{\"changed\": {\"fields\": [\"autores\"]}}]',	10,	1),
(223,	'2020-12-29 07:48:52.077495',	'7',	'INTA',	1,	'[{\"added\": {}}]',	10,	1),
(224,	'2020-12-29 07:49:27.147422',	'7',	'Mel Bartholomew',	2,	'[{\"changed\": {\"fields\": [\"autores\"]}}]',	10,	1),
(225,	'2020-12-29 07:49:47.801411',	'3',	'Cuidar la tierra',	1,	'[{\"added\": {}}]',	17,	1),
(226,	'2020-12-29 07:49:50.844065',	'8',	'Cuidar la tierra',	1,	'[{\"added\": {}}]',	10,	1),
(227,	'2020-12-29 08:30:13.113202',	'8',	'None',	3,	'',	10,	1),
(228,	'2020-12-29 08:30:21.824788',	'7',	'None',	3,	'',	10,	1),
(229,	'2020-12-29 08:30:29.310304',	'6',	'None',	3,	'',	10,	1),
(230,	'2020-12-29 08:34:18.285059',	'9',	'Mel Bartholomew',	1,	'[{\"added\": {}}]',	10,	1),
(231,	'2020-12-30 05:53:58.205704',	'40',	'Taco de Reina',	2,	'[{\"changed\": {\"fields\": [\"familia\"]}}]',	8,	1),
(232,	'2020-12-30 05:54:51.842481',	'41',	'Morrón',	2,	'[{\"changed\": {\"fields\": [\"familia\"]}}]',	8,	1),
(233,	'2020-12-30 05:55:06.625122',	'41',	'Morrón',	2,	'[{\"changed\": {\"fields\": [\"familia\"]}}]',	8,	1),
(234,	'2020-12-30 05:55:52.101455',	'41',	'Morrón',	2,	'[{\"changed\": {\"fields\": [\"familia\"]}}]',	8,	1),
(235,	'2020-12-30 05:57:00.347048',	'12',	'Tropaeolaceae',	1,	'[{\"added\": {}}]',	7,	1),
(236,	'2020-12-30 05:57:50.166410',	'12',	'tropeoláceas',	2,	'[{\"changed\": {\"fields\": [\"nombre_cientifico\", \"nombre_popular\"]}}]',	7,	1),
(237,	'2021-01-02 20:28:27.444817',	'3',	'Acelga',	2,	'[{\"changed\": {\"name\": \"interaccion\", \"object\": \"Acelga\", \"fields\": [\"actor\", \"descripcion\"]}}]',	8,	1),
(238,	'2021-01-02 20:46:44.260477',	'9',	'Mel Bartholomew',	2,	'[{\"added\": {\"name\": \"autor orden\", \"object\": \"AutorOrden object (4)\"}}]',	10,	1),
(239,	'2021-01-02 20:46:55.488430',	'9',	'INTA',	2,	'[{\"added\": {\"name\": \"autor orden\", \"object\": \"AutorOrden object (5)\"}}]',	10,	1),
(240,	'2021-01-02 20:47:06.014300',	'9',	'INTA',	2,	'[{\"changed\": {\"name\": \"autor orden\", \"object\": \"AutorOrden object (5)\", \"fields\": [\"orden\"]}}]',	10,	1),
(241,	'2021-01-02 20:47:28.771329',	'9',	'Mel Bartholomew',	2,	'[{\"deleted\": {\"name\": \"autor orden\", \"object\": \"AutorOrden object (None)\"}}]',	10,	1),
(242,	'2021-01-02 20:47:40.196497',	'9',	'INTA',	2,	'[{\"added\": {\"name\": \"autor orden\", \"object\": \"AutorOrden object (6)\"}}]',	10,	1),
(243,	'2021-01-02 20:50:46.078859',	'4',	'AutorOrden object (4)',	3,	'',	19,	1),
(244,	'2021-01-02 20:50:54.323593',	'6',	'AutorOrden object (6)',	3,	'',	19,	1),
(245,	'2021-01-02 20:52:10.540940',	'11',	'INTA',	1,	'[{\"added\": {}}, {\"added\": {\"name\": \"autor orden\", \"object\": \"AutorOrden object (7)\"}}, {\"added\": {\"name\": \"autor orden\", \"object\": \"AutorOrden object (8)\"}}]',	10,	1),
(246,	'2021-01-02 20:52:47.704846',	'12',	'INTA',	1,	'[{\"added\": {}}, {\"added\": {\"name\": \"autor orden\", \"object\": \"AutorOrden object (9)\"}}, {\"added\": {\"name\": \"autor orden\", \"object\": \"AutorOrden object (10)\"}}]',	10,	1),
(247,	'2021-01-02 20:54:47.483307',	'3',	'Acelga',	2,	'[{\"deleted\": {\"name\": \"interaccion\", \"object\": \"Acelga\"}}]',	8,	1),
(248,	'2021-01-02 22:17:11.642309',	'11',	'INTA',	2,	'[{\"added\": {\"name\": \"autor orden\", \"object\": \"AutorOrden object (14)\"}}]',	10,	1),
(249,	'2021-01-02 22:17:24.760799',	'11',	'INTA',	2,	'[{\"changed\": {\"name\": \"autor orden\", \"object\": \"AutorOrden object (14)\", \"fields\": [\"orden\"]}}]',	10,	1),
(250,	'2021-01-02 22:17:45.332668',	'11',	'INTA',	3,	'',	10,	1),
(251,	'2021-01-02 22:17:55.333424',	'12',	'Mel Bartholomew',	3,	'',	10,	1),
(252,	'2021-01-02 22:18:06.164434',	'9',	'Mel Bartholomew',	2,	'[{\"added\": {\"name\": \"autor orden\", \"object\": \"AutorOrden object (15)\"}}]',	10,	1),
(253,	'2021-01-02 22:26:29.336443',	'9',	'Mel Bartholomew',	2,	'[{\"changed\": {\"fields\": [\"titulo\", \"otros\"]}}]',	10,	1),
(254,	'2021-01-02 22:29:30.478896',	'3',	'Acelga',	2,	'[{\"changed\": {\"name\": \"ficha\", \"object\": \"Acelga\", \"fields\": [\"horas_sol_min\"]}}]',	8,	1),
(255,	'2021-01-02 22:35:25.809792',	'3',	'Acelga',	2,	'[{\"added\": {\"name\": \"interaccion\", \"object\": \"Acelga\"}}]',	8,	1),
(256,	'2021-01-02 22:40:24.105919',	'3',	'Acelga',	2,	'[{\"added\": {\"name\": \"interaccion\", \"object\": \"Acelga\"}}, {\"added\": {\"name\": \"interaccion\", \"object\": \"Acelga\"}}, {\"added\": {\"name\": \"interaccion\", \"object\": \"Acelga\"}}]',	8,	1),
(257,	'2021-01-03 02:56:42.668073',	'42',	'Manzanila',	1,	'[{\"added\": {}}]',	8,	1),
(258,	'2021-01-03 03:31:54.853172',	'16',	'None',	1,	'[{\"added\": {}}]',	10,	1),
(259,	'2021-01-03 03:33:38.704806',	'3',	'Algo',	2,	'[{\"changed\": {\"fields\": [\"primer_nombre\", \"apellido\"]}}]',	17,	1),
(260,	'2021-01-03 03:34:13.905736',	'2',	'None',	3,	'',	17,	1),
(261,	'2021-01-03 03:34:13.982999',	'1',	'None',	3,	'',	17,	1),
(262,	'2021-01-03 03:35:16.386390',	'3',	'Bartholomew',	2,	'[{\"changed\": {\"fields\": [\"primer_nombre\", \"apellido\"]}}]',	17,	1),
(263,	'2021-01-03 03:50:08.610556',	'16',	'None',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	10,	1),
(264,	'2021-01-03 03:57:47.327640',	'16',	'None',	2,	'[]',	10,	1),
(265,	'2021-01-03 03:57:58.949444',	'16',	'Bartholomew',	2,	'[{\"added\": {\"name\": \"autor orden\", \"object\": \"AutorOrden object (17)\"}}]',	10,	1),
(266,	'2021-01-03 03:58:13.904764',	'16',	'Bartholomew',	3,	'',	10,	1),
(267,	'2021-01-03 03:58:20.639984',	'9',	'Bartholomew',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}, {\"added\": {\"name\": \"autor orden\", \"object\": \"AutorOrden object (18)\"}}]',	10,	1),
(268,	'2021-01-03 04:06:20.163775',	'9',	'Bartholomew',	2,	'[]',	10,	1),
(269,	'2021-01-03 04:07:06.424863',	'9',	'Bartholomew',	2,	'[]',	10,	1),
(270,	'2021-01-03 04:09:40.747960',	'9',	'Bartholomew',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	10,	1),
(271,	'2021-01-03 04:09:47.565873',	'9',	'Bartholomew',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	10,	1),
(272,	'2021-01-03 04:34:50.150035',	'9',	'Bartholomew',	2,	'[{\"changed\": {\"fields\": [\"edicion\", \"otros\"]}}]',	10,	1),
(273,	'2021-01-03 04:37:41.451793',	'9',	'Bartholomew',	2,	'[]',	10,	1),
(274,	'2021-01-03 15:22:16.060023',	'9',	'Bartholomew',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	10,	1),
(275,	'2021-01-03 15:22:59.416283',	'9',	'Bartholomew',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	10,	1),
(276,	'2021-01-09 18:54:52.667110',	'3',	'Acelga',	2,	'[{\"changed\": {\"name\": \"interaccion\", \"object\": \"Acelga\", \"fields\": [\"descripcion\"]}}]',	8,	1),
(277,	'2021-01-09 18:55:16.998917',	'3',	'Acelga',	2,	'[{\"changed\": {\"name\": \"interaccion\", \"object\": \"Acelga\", \"fields\": [\"descripcion\"]}}]',	8,	1),
(278,	'2021-01-09 18:56:49.226810',	'3',	'Acelga',	2,	'[{\"changed\": {\"name\": \"interaccion\", \"object\": \"Acelga\", \"fields\": [\"relacion\"]}}]',	8,	1),
(279,	'2021-01-09 19:11:24.047706',	'3',	'Acelga',	2,	'[{\"deleted\": {\"name\": \"interaccion\", \"object\": \"Acelga\"}}]',	8,	1),
(280,	'2021-01-09 19:11:58.638830',	'3',	'Acelga',	2,	'[{\"added\": {\"name\": \"interaccion\", \"object\": \"Acelga\"}}]',	8,	1),
(281,	'2021-01-09 20:05:38.679793',	'7',	'Semillero del ENE a DIC',	1,	'[{\"added\": {}}]',	9,	1),
(282,	'2021-01-09 20:08:09.919300',	'3',	'Acelga',	2,	'[]',	8,	1),
(283,	'2021-01-09 20:08:29.652531',	'7',	'Semillero del ENE a DIC',	3,	'',	9,	1),
(284,	'2021-01-09 20:08:29.793098',	'6',	'Siembra del ENE a DIC',	3,	'',	9,	1),
(285,	'2021-01-09 20:08:29.865994',	'5',	'Semillero del ENE a ENE',	3,	'',	9,	1),
(286,	'2021-01-09 20:08:52.091861',	'8',	'Semillero del ENE a DIC',	1,	'[{\"added\": {}}]',	9,	1),
(287,	'2021-01-09 23:00:59.696760',	'9',	'None del None a None',	1,	'[{\"added\": {}}]',	9,	1),
(288,	'2021-01-10 00:18:48.076615',	'9',	'None del ENE/None a DIC/None',	3,	'',	9,	1),
(289,	'2021-01-10 00:18:48.196342',	'8',	'Semillero del ENE/None a DIC/None',	3,	'',	9,	1),
(290,	'2021-01-10 00:19:19.013574',	'10',	'Semillero del ENE/None a DIC/None',	1,	'[{\"added\": {}}]',	9,	1),
(291,	'2021-01-10 00:21:23.149571',	'4',	'Acelga',	2,	'[]',	16,	1),
(292,	'2021-01-10 00:22:47.289422',	'11',	'Siembra de ENE/None al DIC/None',	1,	'[{\"added\": {}}]',	9,	1),
(293,	'2021-01-10 00:51:49.175597',	'11',	'Siembra de 1/ENE al 31/DIC',	3,	'',	9,	1),
(294,	'2021-01-10 00:51:49.355119',	'10',	'Semillero de 1/ENE al 31/DIC',	3,	'',	9,	1),
(295,	'2021-01-10 00:52:11.244883',	'12',	'Semillero de None al None',	1,	'[{\"added\": {}}]',	9,	1),
(296,	'2021-01-10 00:59:07.327297',	'12',	'Semillero de None al None',	3,	'',	9,	1),
(297,	'2021-01-10 01:14:15.477805',	'13',	'None de None al None',	1,	'[{\"added\": {}}]',	9,	1),
(298,	'2021-01-10 01:20:49.150737',	'14',	'Semillero de 1 al 12',	1,	'[{\"added\": {}}]',	9,	1),
(299,	'2021-01-10 01:21:39.941655',	'15',	'Siembra de 1 al 12',	1,	'[{\"added\": {}}]',	9,	1),
(300,	'2021-01-10 05:20:45.621591',	'16',	'Semillero de None/1 al None/12',	1,	'[{\"added\": {}}]',	9,	1),
(301,	'2021-01-10 05:21:25.539227',	'17',	'None de Enero al Diciembre',	1,	'[{\"added\": {}}]',	9,	1),
(302,	'2021-01-10 05:27:12.621068',	'13',	'None de Enero al Enero',	2,	'[{\"changed\": {\"fields\": [\"desde_mes\", \"hasta_mes\"]}}]',	9,	1),
(303,	'2021-01-10 05:27:26.547355',	'17',	'None de Enero al Diciembre',	3,	'',	9,	1),
(304,	'2021-01-10 05:27:26.806400',	'16',	'Semillero de Enero al Diciembre',	3,	'',	9,	1),
(305,	'2021-01-10 05:27:26.873566',	'15',	'Siembra de Enero al Diciembre',	3,	'',	9,	1),
(306,	'2021-01-10 05:27:26.951690',	'14',	'Semillero de Enero al Diciembre',	3,	'',	9,	1),
(307,	'2021-01-10 05:27:27.230495',	'13',	'None de Enero al Enero',	3,	'',	9,	1),
(308,	'2021-01-10 05:27:45.308692',	'18',	'Semillero de Enero al Diciembre',	1,	'[{\"added\": {}}]',	9,	1),
(309,	'2021-01-10 05:29:24.917703',	'4',	'Acelga',	2,	'[{\"changed\": {\"fields\": [\"epocas\"]}}]',	16,	1),
(310,	'2021-01-10 05:39:31.558454',	'19',	'Siembra de Enero a Diciembre',	1,	'[{\"added\": {}}]',	9,	1),
(311,	'2021-01-10 05:40:51.791144',	'3',	'Acelga',	2,	'[{\"changed\": {\"name\": \"ficha\", \"object\": \"Acelga\", \"fields\": [\"epocas\"]}}, {\"added\": {\"name\": \"interaccion\", \"object\": \"Acelga\"}}, {\"added\": {\"name\": \"interaccion\", \"object\": \"Acelga\"}}, {\"added\": {\"name\": \"interaccion\", \"object\": \"Acelga\"}}]',	8,	1),
(312,	'2021-01-10 18:31:07.622783',	'9',	'Bartholomew',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	10,	1),
(313,	'2021-01-10 18:32:08.576187',	'9',	'Bartholomew',	2,	'[{\"changed\": {\"fields\": [\"titulo\"]}}]',	10,	1),
(314,	'2021-01-10 18:32:57.952791',	'9',	'Bartholomew',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	10,	1),
(315,	'2021-01-10 18:33:16.450049',	'9',	'Bartholomew',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	10,	1),
(316,	'2021-01-10 18:34:42.783370',	'9',	'Bartholomew',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	10,	1),
(317,	'2021-01-10 18:36:32.303429',	'9',	'Bartholomew',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	10,	1),
(318,	'2021-01-10 18:37:58.703567',	'9',	'Bartholomew',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	10,	1),
(319,	'2021-01-10 18:38:03.783540',	'9',	'Bartholomew',	2,	'[]',	10,	1),
(320,	'2021-01-10 18:39:03.088144',	'9',	'Bartholomew',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	10,	1),
(321,	'2021-01-10 19:03:43.113331',	'3',	'Bartholomew',	2,	'[]',	17,	1),
(322,	'2021-01-10 19:12:48.595430',	'3',	'Bartholomew',	2,	'[]',	17,	1),
(323,	'2021-01-10 19:14:52.562642',	'3',	'Bartholomew, Mel',	2,	'[]',	17,	1),
(324,	'2021-01-10 19:14:55.571753',	'3',	'Bartholomew, Mel',	2,	'[]',	17,	1),
(325,	'2021-01-10 19:15:07.813437',	'3',	'Bartholomew, Mel a.',	2,	'[{\"changed\": {\"fields\": [\"segundo_nombre\"]}}]',	17,	1),
(326,	'2021-01-10 19:15:11.134557',	'3',	'Bartholomew, Mel a.',	2,	'[]',	17,	1),
(327,	'2021-01-10 19:15:22.730734',	'3',	'Bartholomew, Mel',	2,	'[{\"changed\": {\"fields\": [\"segundo_nombre\"]}}]',	17,	1),
(328,	'2021-01-10 19:18:05.292592',	'9',	'Bartholomew',	2,	'[{\"changed\": {\"fields\": [\"anio\"]}}]',	10,	1),
(329,	'2021-01-10 19:21:53.816451',	'9',	'Bartholomew',	2,	'[{\"changed\": {\"fields\": [\"titulo\", \"editorial\"]}}]',	10,	1),
(330,	'2021-01-10 19:21:58.230076',	'9',	'Bartholomew',	2,	'[]',	10,	1),
(331,	'2021-01-10 19:32:05.726352',	'18',	'None',	1,	'[{\"added\": {}}]',	10,	1),
(332,	'2021-01-10 19:33:03.424107',	'18',	'None',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	10,	1),
(333,	'2021-01-10 19:39:17.396422',	'4',	'INTA, Instituto Nacional de Tecnología Agropecuaria',	1,	'[{\"added\": {}}]',	17,	1),
(334,	'2021-01-10 19:40:19.047204',	'19',	'INTA, Instituto Nacional de Tecnología Agropecuaria',	1,	'[{\"added\": {}}, {\"added\": {\"name\": \"autor orden\", \"object\": \"AutorOrden object (19)\"}}]',	10,	1),
(335,	'2021-01-10 19:40:56.369775',	'19',	'INTA, Instituto Nacional de Tecnología Agropecuaria',	2,	'[]',	10,	1),
(336,	'2021-01-10 19:42:01.131961',	'19',	'INTA, Instituto Nacional de Tecnología Agropecuaria',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	10,	1),
(337,	'2021-01-10 19:42:09.900359',	'19',	'INTA, Instituto Nacional de Tecnología Agropecuaria',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	10,	1),
(338,	'2021-01-10 19:42:15.358011',	'19',	'INTA, Instituto Nacional de Tecnología Agropecuaria',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	10,	1),
(339,	'2021-01-10 19:42:19.731228',	'19',	'INTA, Instituto Nacional de Tecnología Agropecuaria',	2,	'[]',	10,	1),
(340,	'2021-01-10 19:42:36.685929',	'18',	'None',	3,	'',	10,	1),
(341,	'2021-01-10 19:48:03.450943',	'20',	'None',	1,	'[{\"added\": {}}]',	10,	1),
(342,	'2021-01-10 19:48:11.102930',	'20',	'None',	2,	'[{\"changed\": {\"fields\": [\"tipo\"]}}]',	10,	1),
(343,	'2021-01-10 19:48:15.385412',	'20',	'None',	3,	'',	10,	1);

DROP TABLE IF EXISTS `django_content_type`;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1,	'admin',	'logentry'),
(3,	'auth',	'group'),
(2,	'auth',	'permission'),
(4,	'auth',	'user'),
(5,	'contenttypes',	'contenttype'),
(17,	'plantas',	'autor'),
(19,	'plantas',	'autororden'),
(18,	'plantas',	'autororder'),
(9,	'plantas',	'epoca'),
(7,	'plantas',	'familia'),
(16,	'plantas',	'ficha'),
(10,	'plantas',	'fuente'),
(15,	'plantas',	'interaccion'),
(8,	'plantas',	'planta'),
(14,	'plantas',	'rotacion'),
(11,	'plantas',	'sustrato'),
(13,	'plantas',	'tip'),
(12,	'plantas',	'tipo'),
(6,	'sessions',	'session');

DROP TABLE IF EXISTS `django_migrations`;
CREATE TABLE `django_migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1,	'contenttypes',	'0001_initial',	'2020-12-06 22:12:28.532954'),
(2,	'auth',	'0001_initial',	'2020-12-06 22:12:32.000658'),
(3,	'admin',	'0001_initial',	'2020-12-06 22:12:45.644412'),
(4,	'admin',	'0002_logentry_remove_auto_add',	'2020-12-06 22:12:48.676176'),
(5,	'admin',	'0003_logentry_add_action_flag_choices',	'2020-12-06 22:12:48.778629'),
(6,	'contenttypes',	'0002_remove_content_type_name',	'2020-12-06 22:12:51.413138'),
(7,	'auth',	'0002_alter_permission_name_max_length',	'2020-12-06 22:12:52.879960'),
(8,	'auth',	'0003_alter_user_email_max_length',	'2020-12-06 22:12:53.199174'),
(9,	'auth',	'0004_alter_user_username_opts',	'2020-12-06 22:12:53.299240'),
(10,	'auth',	'0005_alter_user_last_login_null',	'2020-12-06 22:12:54.581280'),
(11,	'auth',	'0006_require_contenttypes_0002',	'2020-12-06 22:12:54.693376'),
(12,	'auth',	'0007_alter_validators_add_error_messages',	'2020-12-06 22:12:54.796780'),
(13,	'auth',	'0008_alter_user_username_max_length',	'2020-12-06 22:12:57.380695'),
(14,	'auth',	'0009_alter_user_last_name_max_length',	'2020-12-06 22:12:59.062109'),
(15,	'auth',	'0010_alter_group_name_max_length',	'2020-12-06 22:12:59.372111'),
(16,	'auth',	'0011_update_proxy_permissions',	'2020-12-06 22:12:59.604766'),
(17,	'plantas',	'0001_initial',	'2020-12-06 22:13:00.965368'),
(18,	'plantas',	'0002_auto_20201206_2153',	'2020-12-06 22:13:11.874667'),
(19,	'sessions',	'0001_initial',	'2020-12-06 22:13:45.292939'),
(20,	'plantas',	'0003_planta_especie',	'2020-12-07 03:08:13.165099'),
(21,	'plantas',	'0004_auto_20201207_0356',	'2020-12-07 03:56:36.066068'),
(22,	'plantas',	'0005_auto_20201207_0358',	'2020-12-07 03:58:37.554472'),
(23,	'plantas',	'0006_auto_20201207_0410',	'2020-12-07 04:10:46.677617'),
(24,	'plantas',	'0007_epoca_estacion',	'2020-12-07 04:24:43.217649'),
(25,	'plantas',	'0008_tip_descripcion',	'2020-12-07 04:44:30.616587'),
(26,	'plantas',	'0009_rotaciones_actual',	'2020-12-07 05:38:41.075613'),
(27,	'plantas',	'0010_auto_20201208_0258',	'2020-12-08 02:59:00.256193'),
(28,	'plantas',	'0011_auto_20201208_0331',	'2020-12-08 03:31:46.489907'),
(29,	'plantas',	'0012_auto_20201208_0335',	'2020-12-08 03:35:11.226443'),
(30,	'plantas',	'0013_auto_20201209_0320',	'2020-12-09 03:22:39.481384'),
(31,	'plantas',	'0014_ficha_tipo',	'2020-12-09 03:22:39.992863'),
(32,	'plantas',	'0015_auto_20201209_0332',	'2020-12-09 03:32:51.291369'),
(33,	'plantas',	'0016_auto_20201227_0253',	'2020-12-27 02:53:51.644201'),
(34,	'plantas',	'0017_auto_20201227_0300',	'2020-12-27 03:00:44.263143'),
(35,	'plantas',	'0018_auto_20201227_0316',	'2020-12-27 03:16:57.958993'),
(36,	'plantas',	'0019_auto_20201227_0323',	'2020-12-27 03:23:22.991899'),
(37,	'plantas',	'0020_auto_20201227_0336',	'2020-12-27 03:36:26.878191'),
(38,	'plantas',	'0021_auto_20201227_0428',	'2020-12-27 04:29:04.313407'),
(39,	'plantas',	'0022_auto_20201227_1547',	'2020-12-27 15:48:21.780660'),
(40,	'plantas',	'0023_auto_20201227_1557',	'2020-12-27 15:57:20.568902'),
(41,	'plantas',	'0024_auto_20201227_1627',	'2020-12-27 16:29:36.794717'),
(42,	'plantas',	'0025_auto_20201227_1629',	'2020-12-27 16:29:46.839177'),
(43,	'plantas',	'0026_auto_20201228_2132',	'2020-12-29 02:04:11.074699'),
(44,	'plantas',	'0027_auto_20201229_0333',	'2020-12-29 03:33:40.680136'),
(45,	'plantas',	'0028_auto_20201229_0412',	'2020-12-29 04:22:26.913945'),
(46,	'plantas',	'0029_auto_20201229_0422',	'2020-12-29 04:22:29.939644'),
(47,	'plantas',	'0030_auto_20201229_0430',	'2020-12-29 04:30:33.788998'),
(48,	'plantas',	'0031_auto_20201229_0440',	'2020-12-29 04:40:45.721525'),
(49,	'plantas',	'0032_auto_20201229_0520',	'2020-12-29 05:26:57.133593'),
(50,	'plantas',	'0033_auto_20201229_0600',	'2020-12-29 06:00:35.894255'),
(51,	'plantas',	'0034_auto_20201229_0605',	'2020-12-29 06:05:44.985001'),
(52,	'plantas',	'0035_auto_20201229_0648',	'2020-12-29 07:07:19.164580'),
(53,	'plantas',	'0036_auto_20201229_0713',	'2020-12-29 07:13:42.883497'),
(54,	'plantas',	'0037_auto_20201229_0723',	'2020-12-29 07:33:36.813651'),
(55,	'plantas',	'0038_auto_20201229_0726',	'2020-12-29 07:33:36.897190'),
(56,	'plantas',	'0039_auto_20201229_0735',	'2020-12-29 07:36:08.516833'),
(57,	'plantas',	'0040_auto_20201229_0743',	'2020-12-29 07:43:08.094518'),
(58,	'plantas',	'0041_auto_20201229_0747',	'2020-12-29 07:48:12.407921'),
(59,	'plantas',	'0042_auto_20201229_0829',	'2020-12-29 08:29:50.172888'),
(60,	'plantas',	'0043_auto_20201229_0837',	'2020-12-29 08:52:24.300801'),
(61,	'plantas',	'0044_ficha_sombra',	'2020-12-29 08:52:25.207754'),
(62,	'plantas',	'0045_auto_20201229_1642',	'2020-12-29 16:45:00.956956'),
(63,	'plantas',	'0046_auto_20210102_1914',	'2021-01-02 20:00:03.785996'),
(64,	'plantas',	'0047_auto_20210102_1958',	'2021-01-02 20:00:11.185573'),
(65,	'plantas',	'0048_auto_20210102_1959',	'2021-01-02 20:00:18.655254'),
(66,	'plantas',	'0049_auto_20210102_2032',	'2021-01-02 20:32:45.495663'),
(67,	'plantas',	'0050_auto_20210102_2223',	'2021-01-02 22:23:17.658687'),
(68,	'plantas',	'0051_auto_20210103_0253',	'2021-01-03 02:54:07.737024'),
(69,	'plantas',	'0052_auto_20210109_1856',	'2021-01-09 18:56:31.368698'),
(70,	'plantas',	'0053_auto_20210109_1929',	'2021-01-09 19:29:48.913259'),
(71,	'plantas',	'0054_auto_20210109_1949',	'2021-01-09 19:51:01.377417'),
(72,	'plantas',	'0055_auto_20210109_2007',	'2021-01-09 20:07:33.987881'),
(73,	'plantas',	'0056_epoca_titulo',	'2021-01-09 23:00:42.669379'),
(74,	'plantas',	'0057_auto_20210110_0027',	'2021-01-10 00:27:44.077173'),
(75,	'plantas',	'0058_auto_20210110_0057',	'2021-01-10 00:57:54.564927'),
(76,	'plantas',	'0059_auto_20210110_0120',	'2021-01-10 01:20:35.070891'),
(77,	'plantas',	'0060_auto_20210110_1836',	'2021-01-10 18:36:10.351900'),
(78,	'plantas',	'0061_auto_20210110_1837',	'2021-01-10 18:37:55.320541'),
(79,	'plantas',	'0062_auto_20210110_1937',	'2021-01-10 19:37:07.585419'),
(80,	'plantas',	'0063_auto_20210110_1938',	'2021-01-10 19:38:51.223060');

DROP TABLE IF EXISTS `django_session`;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('2ti7zrwb16hhjxtxyrvzdkwarbjersjm',	'ZGJjZjhmYWEyMTUwYTllMjVjMTNlMzhiNmE0NDRhNmI3OGViMzY1ODp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhNDZkNjE0MzRiMGJkZjYwMTBlNTg5NjU3NzYwM2JmMjIzNjBmNmU0In0=',	'2020-12-20 22:18:12.331600'),
('qszdnlxhxb6ga916kaablo2ix5i02cyd',	'ZGJjZjhmYWEyMTUwYTllMjVjMTNlMzhiNmE0NDRhNmI3OGViMzY1ODp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhNDZkNjE0MzRiMGJkZjYwMTBlNTg5NjU3NzYwM2JmMjIzNjBmNmU0In0=',	'2021-01-10 01:34:24.511644'),
('rjjmcl674amkp0bvi7pawn5ygioounli',	'ZGJjZjhmYWEyMTUwYTllMjVjMTNlMzhiNmE0NDRhNmI3OGViMzY1ODp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhNDZkNjE0MzRiMGJkZjYwMTBlNTg5NjU3NzYwM2JmMjIzNjBmNmU0In0=',	'2021-01-24 05:20:25.569140');

DROP TABLE IF EXISTS `plantas_autor`;
CREATE TABLE `plantas_autor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `apellido` varchar(200) DEFAULT NULL,
  `primer_nombre` varchar(200) DEFAULT NULL,
  `segundo_nombre` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_autor` (`id`, `apellido`, `primer_nombre`, `segundo_nombre`) VALUES
(3,	'Bartholomew',	'Mel',	NULL),
(4,	'INTA',	'Instituto Nacional de Tecnología Agropecuaria',	NULL);

DROP TABLE IF EXISTS `plantas_autororden`;
CREATE TABLE `plantas_autororden` (
  `id` int NOT NULL AUTO_INCREMENT,
  `orden` int NOT NULL,
  `autor_id` int NOT NULL,
  `fuente_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `plantas_autororden_autor_id_b4e676b9_fk_plantas_autor_id` (`autor_id`),
  KEY `plantas_autororden_fuente_id_81b5c94f_fk_plantas_fuente_id` (`fuente_id`),
  CONSTRAINT `plantas_autororden_autor_id_b4e676b9_fk_plantas_autor_id` FOREIGN KEY (`autor_id`) REFERENCES `plantas_autor` (`id`),
  CONSTRAINT `plantas_autororden_fuente_id_81b5c94f_fk_plantas_fuente_id` FOREIGN KEY (`fuente_id`) REFERENCES `plantas_fuente` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_autororden` (`id`, `orden`, `autor_id`, `fuente_id`) VALUES
(18,	1,	3,	9),
(19,	1,	4,	19);

DROP TABLE IF EXISTS `plantas_autororder`;
CREATE TABLE `plantas_autororder` (
  `id` int NOT NULL AUTO_INCREMENT,
  `number` int unsigned NOT NULL,
  `autor_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `plantas_epoca`;
CREATE TABLE `plantas_epoca` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tipo` varchar(200) DEFAULT NULL,
  `desde_mes` varchar(200) NOT NULL,
  `hasta_mes` varchar(200) NOT NULL,
  `desde_dia` int DEFAULT NULL,
  `hasta_dia` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_epoca` (`id`, `tipo`, `desde_mes`, `hasta_mes`, `desde_dia`, `hasta_dia`) VALUES
(18,	'SE',	'1',	'12',	NULL,	NULL),
(19,	'SI',	'1',	'12',	NULL,	NULL);

DROP TABLE IF EXISTS `plantas_familia`;
CREATE TABLE `plantas_familia` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre_popular` varchar(200) DEFAULT NULL,
  `nombre_cientifico` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_familia` (`id`, `nombre_popular`, `nombre_cientifico`) VALUES
(1,	'Umbelíferas',	'Apiaceae'),
(2,	'Compuesta',	'Asteraceae'),
(3,	'Crucíferas',	'Brassicaceae'),
(4,	'Solanáceas',	'Solanaceae'),
(5,	'Cucurbitáceas',	'Cucurbitaceae'),
(6,	'Gramíneas',	'Poaceae'),
(7,	'Leguminosas',	'Fabaceae'),
(8,	'Quenopoidáceas',	'Chenopodioideae'),
(9,	'Alliáceas',	'Allioideae'),
(10,	'Labiadas',	'Lamiaceae'),
(11,	'Rosáceas',	'Rosaceae'),
(12,	'tropeoláceas',	'Tropaeolaceae');

DROP TABLE IF EXISTS `plantas_ficha`;
CREATE TABLE `plantas_ficha` (
  `id` int NOT NULL AUTO_INCREMENT,
  `volumen_maceta_ltr` decimal(5,0) DEFAULT NULL,
  `profundidad_cm` decimal(5,0) DEFAULT NULL,
  `tamano` varchar(200) DEFAULT NULL,
  `horas_sol_min` decimal(5,0) DEFAULT NULL,
  `horas_sol_max` decimal(5,0) DEFAULT NULL,
  `riego` varchar(200) DEFAULT NULL,
  `tiempo_cultivo_semanas` int DEFAULT NULL,
  `tutorado` tinyint(1) NOT NULL,
  `planta_id` int DEFAULT NULL,
  `distancia_cm` decimal(5,0) DEFAULT NULL,
  `temperatura_max` decimal(5,0) DEFAULT NULL,
  `temperatura_min` decimal(5,0) DEFAULT NULL,
  `soporta_sombra` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plantas_ficha_planta_id_77990985_uniq` (`planta_id`),
  CONSTRAINT `plantas_ficha_planta_id_77990985_fk_plantas_planta_id` FOREIGN KEY (`planta_id`) REFERENCES `plantas_planta` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_ficha` (`id`, `volumen_maceta_ltr`, `profundidad_cm`, `tamano`, `horas_sol_min`, `horas_sol_max`, `riego`, `tiempo_cultivo_semanas`, `tutorado`, `planta_id`, `distancia_cm`, `temperatura_max`, `temperatura_min`, `soporta_sombra`) VALUES
(2,	2,	25,	'S',	20,	6,	'1xD',	10,	0,	1,	NULL,	NULL,	NULL,	0),
(3,	4,	15,	'M',	20,	4,	'2xD',	4,	0,	2,	NULL,	NULL,	NULL,	0),
(4,	4,	15,	'M',	4,	4,	'2xD',	12,	0,	3,	NULL,	NULL,	NULL,	0),
(5,	40,	40,	'L',	25,	5,	'c2D',	1,	0,	37,	NULL,	NULL,	NULL,	0);

DROP TABLE IF EXISTS `plantas_ficha_epocas`;
CREATE TABLE `plantas_ficha_epocas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ficha_id` int NOT NULL,
  `epoca_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plantas_ficha_epocas_ficha_id_epoca_id_60e7f44c_uniq` (`ficha_id`,`epoca_id`),
  KEY `plantas_ficha_epocas_epoca_id_3a0d1f1e_fk_plantas_epoca_id` (`epoca_id`),
  CONSTRAINT `plantas_ficha_epocas_epoca_id_3a0d1f1e_fk_plantas_epoca_id` FOREIGN KEY (`epoca_id`) REFERENCES `plantas_epoca` (`id`),
  CONSTRAINT `plantas_ficha_epocas_ficha_id_a17112c4_fk_plantas_ficha_id` FOREIGN KEY (`ficha_id`) REFERENCES `plantas_ficha` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_ficha_epocas` (`id`, `ficha_id`, `epoca_id`) VALUES
(2,	4,	19);

DROP TABLE IF EXISTS `plantas_ficha_fuentes`;
CREATE TABLE `plantas_ficha_fuentes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ficha_id` int NOT NULL,
  `fuente_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plantas_ficha_fuentes_ficha_id_fuente_id_8dd8987e_uniq` (`ficha_id`,`fuente_id`),
  KEY `plantas_ficha_fuentes_fuente_id_23132f93_fk_plantas_fuente_id` (`fuente_id`),
  CONSTRAINT `plantas_ficha_fuentes_ficha_id_2600f209_fk_plantas_ficha_id` FOREIGN KEY (`ficha_id`) REFERENCES `plantas_ficha` (`id`),
  CONSTRAINT `plantas_ficha_fuentes_fuente_id_23132f93_fk_plantas_fuente_id` FOREIGN KEY (`fuente_id`) REFERENCES `plantas_fuente` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `plantas_ficha_sustrato`;
CREATE TABLE `plantas_ficha_sustrato` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ficha_id` int NOT NULL,
  `sustrato_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plantas_ficha_sustrato_ficha_id_sustrato_id_f2609d69_uniq` (`ficha_id`,`sustrato_id`),
  KEY `plantas_ficha_sustra_sustrato_id_4aedc587_fk_plantas_s` (`sustrato_id`),
  CONSTRAINT `plantas_ficha_sustra_sustrato_id_4aedc587_fk_plantas_s` FOREIGN KEY (`sustrato_id`) REFERENCES `plantas_sustrato` (`id`),
  CONSTRAINT `plantas_ficha_sustrato_ficha_id_aea9e53b_fk_plantas_ficha_id` FOREIGN KEY (`ficha_id`) REFERENCES `plantas_ficha` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_ficha_sustrato` (`id`, `ficha_id`, `sustrato_id`) VALUES
(3,	2,	1);

DROP TABLE IF EXISTS `plantas_ficha_tips`;
CREATE TABLE `plantas_ficha_tips` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ficha_id` int NOT NULL,
  `tip_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plantas_ficha_tips_ficha_id_tip_id_2156d431_uniq` (`ficha_id`,`tip_id`),
  KEY `plantas_ficha_tips_tip_id_96bbadf3_fk_plantas_tip_id` (`tip_id`),
  CONSTRAINT `plantas_ficha_tips_ficha_id_a6e5af8e_fk_plantas_ficha_id` FOREIGN KEY (`ficha_id`) REFERENCES `plantas_ficha` (`id`),
  CONSTRAINT `plantas_ficha_tips_tip_id_96bbadf3_fk_plantas_tip_id` FOREIGN KEY (`tip_id`) REFERENCES `plantas_tip` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_ficha_tips` (`id`, `ficha_id`, `tip_id`) VALUES
(2,	2,	2),
(4,	4,	3);

DROP TABLE IF EXISTS `plantas_fuente`;
CREATE TABLE `plantas_fuente` (
  `id` int NOT NULL AUTO_INCREMENT,
  `otros` longtext,
  `url` varchar(200) DEFAULT NULL,
  `titulo` longtext,
  `acceso` date DEFAULT NULL,
  `anio` longtext,
  `articulo` longtext,
  `capitulo` longtext,
  `contenido` longtext,
  `edicion` int DEFAULT NULL,
  `editorial` longtext,
  `nombre_pag` longtext,
  `numero` int DEFAULT NULL,
  `pag_fin` int DEFAULT NULL,
  `pag_inicio` int DEFAULT NULL,
  `red_social` varchar(10) DEFAULT NULL,
  `tipo` varchar(20) DEFAULT NULL,
  `tipo_cont` longtext,
  `usuario` longtext,
  `volumen` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_fuente` (`id`, `otros`, `url`, `titulo`, `acceso`, `anio`, `articulo`, `capitulo`, `contenido`, `edicion`, `editorial`, `nombre_pag`, `numero`, `pag_fin`, `pag_inicio`, `red_social`, `tipo`, `tipo_cont`, `usuario`, `volumen`) VALUES
(9,	'',	NULL,	'All new square foot gardening : more projects, new solutions, grow vegetables anywhere',	NULL,	'2018',	'',	'',	'',	3,	'Cool Springs Press',	'',	NULL,	NULL,	NULL,	NULL,	'LI',	'',	'',	NULL),
(19,	'',	NULL,	'',	NULL,	'',	NULL,	NULL,	NULL,	NULL,	'',	'',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL);

DROP TABLE IF EXISTS `plantas_interaccion`;
CREATE TABLE `plantas_interaccion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `target_id` int DEFAULT NULL,
  `relacion` longtext,
  `tipo` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `plantas_interacciones_target_id_29d24dc1_fk_plantas_planta_id` (`target_id`),
  CONSTRAINT `plantas_interacciones_target_id_29d24dc1_fk_plantas_planta_id` FOREIGN KEY (`target_id`) REFERENCES `plantas_planta` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_interaccion` (`id`, `target_id`, `relacion`, `tipo`) VALUES
(1,	1,	NULL,	'B'),
(6,	37,	NULL,	'B'),
(7,	3,	'',	'B'),
(8,	3,	'',	'B'),
(9,	3,	'',	'B'),
(11,	3,	'',	'B'),
(12,	3,	'',	'B'),
(13,	3,	'',	'B'),
(14,	3,	'',	'B');

DROP TABLE IF EXISTS `plantas_interaccion_actor`;
CREATE TABLE `plantas_interaccion_actor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `interaccion_id` int NOT NULL,
  `planta_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plantas_interaccion_actor_interaccion_id_planta_id_5c65194c_uniq` (`interaccion_id`,`planta_id`),
  KEY `plantas_interaccion__planta_id_31a3b788_fk_plantas_p` (`planta_id`),
  CONSTRAINT `plantas_interaccion__interaccion_id_14e154e2_fk_plantas_i` FOREIGN KEY (`interaccion_id`) REFERENCES `plantas_interaccion` (`id`),
  CONSTRAINT `plantas_interaccion__planta_id_31a3b788_fk_plantas_p` FOREIGN KEY (`planta_id`) REFERENCES `plantas_planta` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_interaccion_actor` (`id`, `interaccion_id`, `planta_id`) VALUES
(2,	7,	5),
(3,	8,	39),
(4,	9,	40),
(6,	11,	17),
(7,	12,	42),
(8,	13,	34),
(9,	14,	1);

DROP TABLE IF EXISTS `plantas_planta`;
CREATE TABLE `plantas_planta` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre_popular` varchar(200) DEFAULT NULL,
  `nombre_cientifico` varchar(200) DEFAULT NULL,
  `familia_id` int DEFAULT NULL,
  `variedad` varchar(200) DEFAULT NULL,
  `tipo_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `plantas_planta_tipo_id_b6de5d3c_fk_plantas_tipo_id` (`tipo_id`),
  KEY `plantas_planta_familia_id_77279843_fk_plantas_familia_id` (`familia_id`),
  CONSTRAINT `plantas_planta_familia_id_77279843_fk_plantas_familia_id` FOREIGN KEY (`familia_id`) REFERENCES `plantas_familia` (`id`),
  CONSTRAINT `plantas_planta_tipo_id_b6de5d3c_fk_plantas_tipo_id` FOREIGN KEY (`tipo_id`) REFERENCES `plantas_tipo` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_planta` (`id`, `nombre_popular`, `nombre_cientifico`, `familia_id`, `variedad`, `tipo_id`) VALUES
(1,	'Zanahoria',	'Daucus carota',	1,	'Sativa',	4),
(2,	'Lechuga',	'Lactuca',	2,	'Sativa',	3),
(3,	'Acelga',	'Beta vulgaris',	8,	'Cicla',	3),
(4,	'Albahaca',	'Ocimum basilicum',	10,	'Cicla',	2),
(5,	'Ajo',	'Allium sativun',	9,	'sativa',	4),
(6,	'Apio',	'Apium graveolens',	1,	'Común',	2),
(7,	'Arveja',	'Pisum sativum',	7,	'Sativa',	1),
(8,	'Berenjena',	NULL,	4,	NULL,	1),
(9,	'Brócoli',	NULL,	3,	NULL,	2),
(10,	'Coliflor',	NULL,	3,	NULL,	2),
(11,	'Cebolla',	NULL,	9,	NULL,	4),
(12,	'Cebolla de verdeo',	NULL,	9,	NULL,	2),
(13,	'Chaucha',	NULL,	7,	NULL,	1),
(14,	'Maíz',	NULL,	6,	NULL,	1),
(15,	'Espárrago',	NULL,	9,	NULL,	4),
(16,	'Espinaca',	NULL,	8,	NULL,	3),
(17,	'Frutilla',	'Fragaria',	11,	NULL,	1),
(18,	'Haba',	NULL,	7,	NULL,	1),
(19,	'Hinojo',	NULL,	1,	NULL,	2),
(21,	'Escarola',	NULL,	2,	NULL,	3),
(22,	'Melón',	NULL,	5,	NULL,	1),
(23,	'Sandía',	NULL,	5,	NULL,	1),
(24,	'Papa',	NULL,	4,	NULL,	4),
(25,	'Pepino',	NULL,	5,	NULL,	1),
(26,	'Perejil',	NULL,	1,	NULL,	2),
(27,	'Pimiento',	NULL,	4,	NULL,	1),
(28,	'Puerro',	NULL,	9,	NULL,	2),
(29,	'Rabanito',	NULL,	3,	NULL,	4),
(30,	'Radicheta',	NULL,	2,	NULL,	3),
(31,	'Remolacha',	NULL,	8,	NULL,	4),
(32,	'Repollo',	NULL,	3,	NULL,	2),
(33,	'Rúcula',	NULL,	3,	NULL,	3),
(34,	'Tomate',	NULL,	4,	NULL,	1),
(35,	'Zapallo',	NULL,	5,	NULL,	1),
(36,	'Cayote',	NULL,	5,	NULL,	1),
(37,	'Zapallito',	NULL,	5,	NULL,	1),
(38,	'Zuccini',	NULL,	5,	NULL,	1),
(39,	'Caléndula',	NULL,	2,	NULL,	2),
(40,	'Taco de Reina',	NULL,	11,	NULL,	2),
(41,	'Morrón',	NULL,	4,	NULL,	1),
(42,	'Manzanila',	NULL,	NULL,	NULL,	2);

DROP TABLE IF EXISTS `plantas_rotacion`;
CREATE TABLE `plantas_rotacion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `anterior_id` int DEFAULT NULL,
  `posterior_id` int DEFAULT NULL,
  `actual_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `plantas_rotaciones_anterior_id_f8637944_fk_plantas_familia_id` (`anterior_id`),
  KEY `plantas_rotaciones_posterior_id_93dca290_fk_plantas_familia_id` (`posterior_id`),
  KEY `plantas_rotaciones_actual_id_d25be4a3_fk_plantas_familia_id` (`actual_id`),
  CONSTRAINT `plantas_rotaciones_actual_id_d25be4a3_fk_plantas_familia_id` FOREIGN KEY (`actual_id`) REFERENCES `plantas_familia` (`id`),
  CONSTRAINT `plantas_rotaciones_anterior_id_f8637944_fk_plantas_familia_id` FOREIGN KEY (`anterior_id`) REFERENCES `plantas_familia` (`id`),
  CONSTRAINT `plantas_rotaciones_posterior_id_93dca290_fk_plantas_familia_id` FOREIGN KEY (`posterior_id`) REFERENCES `plantas_familia` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_rotacion` (`id`, `anterior_id`, `posterior_id`, `actual_id`) VALUES
(3,	5,	3,	2),
(4,	3,	4,	1),
(5,	2,	1,	3),
(6,	1,	6,	4),
(7,	4,	7,	6),
(8,	6,	8,	7),
(9,	7,	9,	8),
(10,	8,	5,	9);

DROP TABLE IF EXISTS `plantas_sustrato`;
CREATE TABLE `plantas_sustrato` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tierra` varchar(200) DEFAULT NULL,
  `potasio` tinyint(1) NOT NULL,
  `nitrogeno` tinyint(1) NOT NULL,
  `fosforo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_sustrato` (`id`, `tierra`, `potasio`, `nitrogeno`, `fosforo`) VALUES
(1,	'Suelto',	0,	0,	0);

DROP TABLE IF EXISTS `plantas_tip`;
CREATE TABLE `plantas_tip` (
  `id` int NOT NULL AUTO_INCREMENT,
  `contenido` longtext,
  `fuente_id` int DEFAULT NULL,
  `titulo` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `plantas_tip_fuente_id_6c2d03a8_fk_plantas_fuente_id` (`fuente_id`),
  CONSTRAINT `plantas_tip_fuente_id_6c2d03a8_fk_plantas_fuente_id` FOREIGN KEY (`fuente_id`) REFERENCES `plantas_fuente` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_tip` (`id`, `contenido`, `fuente_id`, `titulo`) VALUES
(2,	'Cuando asome de la tierra',	NULL,	'Cosecha raíces'),
(3,	'Corte de tallos florales que se van secando',	NULL,	'Cosecha semilla acelga');

DROP TABLE IF EXISTS `plantas_tipo`;
CREATE TABLE `plantas_tipo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_tipo` (`id`, `nombre`) VALUES
(1,	'FR'),
(2,	'FL'),
(3,	'HO'),
(4,	'RA');

-- 2021-01-10 19:51:23
